package pulse;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_7172;
import pulse.module.ClientModule;
import pulse.module.ModuleCategory;
import pulse.module.ModuleInfo;

@ModuleInfo(a = "Full Bright", b = "Increases world brightness", c = ModuleCategory.VISUALS)
public class FullBright extends ClientModule {
   private static final double FULL_BRIGHT_GAMMA = 9999.0;

   private double previousGamma = 1.0;

   @Override
   public void e() {
      if (c.field_1690 == null) {
         return;
      }

      this.previousGamma = c.field_1690.method_42473().method_41753();
      c.field_1690.method_42473().method_41748(FULL_BRIGHT_GAMMA);
   }

   @Override
   public void f() {
      if (c.field_1690 != null) {
         c.field_1690.method_42473().method_41748(this.previousGamma);
      }

      super.f();
   }

   @EventHandler
   public void a(ClientTickEvent event) {
      if (c.field_1690 == null) {
         return;
      }

      class_7172<Double> gamma = c.field_1690.method_42473();
      if (gamma.method_41753() != FULL_BRIGHT_GAMMA) {
         gamma.method_41748(FULL_BRIGHT_GAMMA);
      }
   }
}

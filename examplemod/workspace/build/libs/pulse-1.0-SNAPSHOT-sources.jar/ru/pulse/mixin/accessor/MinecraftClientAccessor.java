package ru.pulse.mixin.accessor;

import net.minecraft.class_310;
import net.minecraft.class_320;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_310.class)
public interface MinecraftClientAccessor {
   @Accessor("session")
   class_320 getSession();

   @Invoker("doItemUse")
   void invokeDoItemUse();

   @Invoker("doAttack")
   boolean invokeDoAttack();
}

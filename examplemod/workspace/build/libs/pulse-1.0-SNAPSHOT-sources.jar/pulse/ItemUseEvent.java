package pulse;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1937;

public class ItemUseEvent extends CancellablePulseEvent {
   private final class_1657 player;
   private final class_1937 world;
   private final class_1268 hand;

   public ItemUseEvent(class_1657 player, class_1937 world, class_1268 hand) {
      this.player = player;
      this.world = world;
      this.hand = hand;
   }

   public class_1657 player() {
      return this.player;
   }

   public class_1937 world() {
      return this.world;
   }

   public class_1268 hand() {
      return this.hand;
   }

   public class_1657 d() {
      return this.player;
   }

   public class_1937 e() {
      return this.world;
   }

   public class_1268 f() {
      return this.hand;
   }
}

package pulse;

import net.minecraft.class_1799;

public class ItemOverlayRenderEvent extends PulseEvent {
   private final class_1799 stack;
   private final int x;
   private final int y;

   public ItemOverlayRenderEvent(class_1799 stack, int x, int y) {
      this.stack = stack;
      this.x = x;
      this.y = y;
   }

   public class_1799 stack() {
      return this.stack;
   }

   public int x() {
      return this.x;
   }

   public int y() {
      return this.y;
   }

   public class_1799 a() {
      return this.stack;
   }

   public int b() {
      return this.x;
   }

   public int c() {
      return this.y;
   }
}

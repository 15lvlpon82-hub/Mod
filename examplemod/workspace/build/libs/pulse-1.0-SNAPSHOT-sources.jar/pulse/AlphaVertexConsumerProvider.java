package pulse;

import net.minecraft.class_1921;
import net.minecraft.class_4588;
import net.minecraft.class_4597;

public class AlphaVertexConsumerProvider implements class_4597 {
   private final class_4597 delegate;
   private final float alphaMultiplier;

   public AlphaVertexConsumerProvider(class_4597 delegate, float alphaMultiplier) {
      this.delegate = delegate;
      this.alphaMultiplier = alphaMultiplier;
   }

   public class_4588 getBuffer(class_1921 layer) {
      return new AlphaVertexConsumer(this.delegate.getBuffer(layer), this.alphaMultiplier);
   }
}

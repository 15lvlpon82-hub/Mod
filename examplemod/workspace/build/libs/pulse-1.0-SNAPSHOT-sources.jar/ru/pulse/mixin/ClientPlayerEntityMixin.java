package ru.pulse.mixin;

import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.EventBusService;
import pulse.DropItemEvent;
import pulse.ClientTickEvent;

@Mixin(class_746.class)
public class ClientPlayerEntityMixin {
   @Inject(method = "tick", at = @At("HEAD"))
   private void onTick(CallbackInfo var1) {
      EventBusService.EVENT_BUS.post(new ClientTickEvent());
   }

   @Inject(method = "dropSelectedItem", at = @At("HEAD"), cancellable = true)
   private void onDropSelectedItem(boolean var1, CallbackInfoReturnable<Boolean> var2) {
      class_746 var3 = (class_746)(Object)this;
      DropItemEvent var4 = new DropItemEvent(var3.method_31548().field_7545, var1);
      EventBusService.EVENT_BUS.post(var4);
      if (var4.c()) {
         var2.setReturnValue(false);
      }
   }
}

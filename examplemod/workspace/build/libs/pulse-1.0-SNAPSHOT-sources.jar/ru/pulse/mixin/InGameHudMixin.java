package ru.pulse.mixin;


import pulse.module.ModuleRegistry;
import java.util.function.Function;
import net.minecraft.class_1306;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1921;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_355;
import net.minecraft.class_4587;
import net.minecraft.class_746;
import net.minecraft.class_8646;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.EventBusService;
import pulse.HudElementManager;
import pulse.HudRenderPostEvent;
import pulse.HudRenderPreEvent;
import pulse.Cooldowns;
import pulse.FastSwap;
import pulse.HotbarSelectionAnimation;
import pulse.PlayerListScaleAnimation;
import pulse.Animations;
import pulse.Crosshair;
import pulse.RenderTweaks;
import pulse.KeyNameFormatter;
import pulse.GuiInput;
import pulse.ScreenScale;
import pulse.ScreenPoint;
import pulse.CooldownInfo;

@Mixin(class_329.class)
public abstract class InGameHudMixin {
   @Shadow
   @Final
   private static class_2960 HOTBAR_SELECTION_TEXTURE;
   @Shadow
   @Final
   private class_310 client;
   @Shadow
   @Final
   private class_355 playerListHud;
   @Unique
   private boolean deferHighlight = false;
   @Unique
   private int deferredHighlightY;
   @Unique
   private boolean prevTabShown = false;

   @Shadow
   private void renderHotbarItem(class_332 var1, int var2, int var3, class_9779 var4, class_1657 var5, class_1799 var6, int var7) {
   }

   @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
   private void onRenderCrosshair(class_332 var1, class_9779 var2, CallbackInfo var3) {
      Crosshair var4 = ModuleRegistry.CROSSHAIR;
      if (var4 != null && var4.k()) {
         var3.cancel();
      }
   }

   @Unique
   private boolean isHotbarAnimationEnabled() {
      return ModuleRegistry.ANIMATIONS != null && ModuleRegistry.ANIMATIONS.k() && ModuleRegistry.ANIMATIONS.g.a();
   }

   @Inject(method = "renderHotbar", at = @At("HEAD"))
   private void onRenderHotbarHead(class_332 var1, class_9779 var2, CallbackInfo var3) {
      if (this.isHotbarAnimationEnabled() && this.client.field_1724 != null) {
         HotbarSelectionAnimation var4 = Animations.p();
         int var5 = this.client.field_1724.method_31548().field_7545;
         int var6 = var1.method_51421() / 2;
         var4.a(var5, var6, (long)ModuleRegistry.ANIMATIONS.h.k().floatValue());
         var4.a();
      }
   }

   @Redirect(
      method = "renderHotbar",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Ljava/util/function/Function;Lnet/minecraft/util/Identifier;IIII)V",
         ordinal = 1
      )
   )
   private void redirectHotbarSelection(class_332 var1, Function<class_2960, class_1921> var2, class_2960 var3, int var4, int var5, int var6, int var7) {
      if (this.isHotbarAnimationEnabled()) {
         this.deferredHighlightY = var5;
         this.deferHighlight = true;
      } else {
         var1.method_52706(var2, var3, var4, var5, var6, var7);
      }
   }

   @Inject(method = "renderHotbar", at = @At("RETURN"))
   private void renderDeferredHighlight(class_332 var1, class_9779 var2, CallbackInfo var3) {
      if (this.deferHighlight) {
         this.deferHighlight = false;
         int var4 = Math.round(Animations.p().b());
         var1.method_51452();
         class_4587 var5 = var1.method_51448();
         var5.method_22903();
         var5.method_46416(0.0F, 0.0F, 200.0F);
         var1.method_52706(class_1921::method_62277, HOTBAR_SELECTION_TEXTURE, var4, this.deferredHighlightY, 24, 23);
         var5.method_22909();
      }
   }

   @Inject(method = "renderHotbar", at = @At("RETURN"))
   private void renderArmorHud(class_332 var1, class_9779 var2, CallbackInfo var3) {
      if (ModuleRegistry.ARMOR_HUD.k() && class_310.method_1551().field_1724 != null) {
         class_746 var4 = this.client.field_1724;
         if (var4 != null) {
            int var5 = var1.method_51421() / 2;
            class_1799 var6 = var4.method_6079();
            class_1306 var7 = var4.method_6068().method_5928();
            int var8 = var7 == class_1306.field_6183 && !var6.method_7960() ? 24 : 0;

            for (int var9 = 0; var9 < 4; var9++) {
               int var10 = var5 + 92 + 10 + var9 * 20 + 2 + var8;
               int var11 = var1.method_51443() - 16 - 3;
               class_1799 var12 = var4.method_31548().method_7372(3 - var9);
               this.renderHotbarItem(var1, var10, var11, var2, var4, var12, var9 + 1);
            }
         }
      }
   }

   @Inject(
      method = "renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V",
      at = @At("HEAD"),
      cancellable = true
   )
   private void onRenderScoreboardSidebar(class_332 var1, class_266 var2, CallbackInfo var3) {
      RenderTweaks var4 = ModuleRegistry.RENDER_TWEAKS;
      if (var4 != null && var4.r()) {
         var3.cancel();
      }
   }

   @Inject(method = "render", at = @At("HEAD"))
   private void onRenderPre(class_332 var1, class_9779 var2, CallbackInfo var3) {
      int var4 = (int)GuiInput.e();
      int var5 = (int)GuiInput.f();
      ScreenPoint var6 = ScreenScale.a(var4, var5);
      EventBusService.EVENT_BUS.post(new HudRenderPreEvent(var1.method_51448(), var6.a(), var6.b(), var2.method_60637(true)));
   }

   @Inject(method = "render", at = @At("TAIL"))
   private void onRender(class_332 var1, class_9779 var2, CallbackInfo var3) {
      int var4 = (int)GuiInput.e();
      int var5 = (int)GuiInput.f();
      ScreenPoint var6 = ScreenScale.a(var4, var5);
      ScreenScale.a(2.0);
      EventBusService.EVENT_BUS.post(new HudRenderPostEvent(var1.method_51448(), var6.a(), var6.b(), var2.method_60637(true)));
      ScreenScale.a();
      HudElementManager.a().a(var1.method_51448());
      HudElementManager.a().b(var1.method_51448());
   }

   @Inject(method = "renderPlayerList", at = @At("HEAD"), cancellable = true)
   private void onRenderPlayerList(class_332 var1, class_9779 var2, CallbackInfo var3) {
      if (ModuleRegistry.ANIMATIONS != null && ModuleRegistry.ANIMATIONS.k() && ModuleRegistry.ANIMATIONS.a.a()) {
         var3.cancel();
         if (this.client.field_1687 != null && this.client.field_1724 != null) {
            class_269 var4 = this.client.field_1687.method_8428();
            class_266 var5 = var4.method_1189(class_8646.field_45156);
            boolean var6 = this.client.field_1690.field_1907.method_1434();
            boolean var7 = this.client.method_1542() && this.client.field_1724.field_3944.method_45732().size() <= 1 && var5 == null;
            boolean var8 = var6 && !var7;
            PlayerListScaleAnimation var9 = Animations.n();
            long var10 = (long)ModuleRegistry.ANIMATIONS.b.k().floatValue();
            if (var8 && !this.prevTabShown) {
               var9.a(var10);
            } else if (!var8 && this.prevTabShown) {
               var9.b(var10);
            }

            this.prevTabShown = var8;
            var9.a();
            boolean var12 = var8 || var9.d();
            if (!var12) {
               this.playerListHud.method_1921(false);
            } else {
               this.playerListHud.method_1921(true);
               float var13 = var9.b();
               if (var13 < 0.001F) {
                  this.playerListHud.method_1921(false);
               } else {
                  class_4587 var14 = var1.method_51448();
                  var14.method_22903();
                  float var15 = var1.method_51421() / 2.0F;
                  var14.method_46416(var15, 0.0F, 0.0F);
                  var14.method_22905(var13, var13, 1.0F);
                  var14.method_46416(-var15, 0.0F, 0.0F);
                  this.playerListHud.method_1919(var1, var1.method_51421(), var4, var5);
                  var14.method_22909();
               }
            }
         }
      } else {
         this.prevTabShown = false;
      }
   }

   @Inject(method = "renderHotbar", at = @At("TAIL"))
   private void renderHotbarItemBinds(class_332 var1, class_9779 var2, CallbackInfo var3) {
      class_310 var4 = class_310.method_1551();
      class_746 var5 = var4.field_1724;
      if (var5 != null) {
         FastSwap var6 = ModuleRegistry.FAST_SWAP;
         boolean var7 = var6 != null && var6.E().k() && var6.k();
         Cooldowns var8 = ModuleRegistry.COOLDOWNS;
         boolean var9 = var8 != null && var8.k() && var8.n();
         class_327 var10 = var4.field_1772;
         int var11 = var1.method_51421();
         int var12 = var1.method_51443();

         for (int var13 = 0; var13 < 9; var13++) {
            class_1799 var14 = var5.method_31548().method_5438(var13);
            if (!var14.method_7960()) {
               int var15 = this.getKey(var14, var6);
               boolean var16 = var9 && this.hasAnyCooldown(var14, var8);
               boolean var17 = var15 != -1 && var15 != 0;
               if (var16 || var17) {
                  int var18 = var11 / 2 - 91 + var13 * 20 + 2;
                  int var19 = var12 - 16 - 3;
                  if (var17 && !var16 && var7) {
                     String var20 = KeyNameFormatter.a(var15);
                     float var21 = var10.method_1727(var20);
                     float var22 = 14.0F;
                     float var23 = Math.min(1.0F, var22 / var21);
                     float var24 = var6.F().k();
                     float var25 = var23 * var24;
                     class_4587 var26 = var1.method_51448();
                     var26.method_22903();
                     var26.method_46416(0.0F, 0.0F, 400.0F);
                     var26.method_22905(var25, var25, 1.0F);
                     var1.method_51433(var10, var20, (int)((var18 + 2.0F) / var25), (int)((var19 + 1.0F) / var25), 16777215, true);
                     var26.method_22909();
                  }

                  if (var16) {
                     CooldownInfo.ItemCooldownSnapshot var30 = CooldownInfo.a(var5.method_7357(), var14.method_7909());
                     int var31;
                     int var32;
                     if (Cooldowns.a(var14) && var8.b(var14.method_7909())) {
                        float var34 = var8.a(var14.method_7909());
                        var31 = (int)Math.ceil(var34 * 18.5);
                        var32 = var34 <= 0.33F ? 65280 : (var34 <= 0.66F ? 16776960 : 16711680);
                     } else {
                        var31 = (int)Math.ceil(var30.b());
                        float var33 = var30.c();
                        var32 = var33 <= 0.33F ? 65280 : (var33 <= 0.66F ? 16776960 : 16711680);
                     }

                     String var35 = String.valueOf(var31);
                     float var36 = var10.method_1727(var35);
                     float var37 = 14.0F;
                     float var38 = Math.min(1.0F, var37 / var36);
                     float var27 = var8.q().k();
                     float var28 = var38 * var27;
                     class_4587 var29 = var1.method_51448();
                     var29.method_22903();
                     var29.method_46416(0.0F, 0.0F, 400.0F);
                     var29.method_22905(var28, var28, 1.0F);
                     var1.method_51433(var10, var35, (int)((var18 + 2.0F) / var28), (int)((var19 + 1.0F) / var28), var32, true);
                     var29.method_22909();
                  }
               }
            }
         }
      }
   }

   @Unique
   private boolean hasAnyCooldown(class_1799 var1, Cooldowns var2) {
      CooldownInfo.ItemCooldownSnapshot var3 = CooldownInfo.a(class_310.method_1551().field_1724.method_7357(), var1.method_7909());
      return var3.a() || Cooldowns.a(var1) && var2.b(var1.method_7909());
   }

   @Unique
   private int getKey(class_1799 var1, FastSwap var2) {
      if (var2 == null) {
         return -1;
      } else {
         class_1792 var3 = var1.method_7909();
         if (var3 == class_1802.field_22021) {
            return this.getKeyOrDefault(var2.q().a());
         } else if (var3 == class_1802.field_8551) {
            return this.getKeyOrDefault(var2.r().a());
         } else if (var3 == class_1802.field_8449) {
            int var4 = var2.s().a();
            return var4 > 0 ? var4 : this.getKeyOrDefault(var2.y().a());
         } else if (var3 == class_1802.field_8479) {
            return this.getKeyOrDefault(var2.t().a());
         } else if (var3 == class_1802.field_8233) {
            return this.getKeyOrDefault(var2.n().a());
         } else if (var3 == class_1802.field_8634) {
            return this.getKeyOrDefault(var2.o().a());
         } else if (var3 == class_1802.field_8574 && var2.a(var1)) {
            return this.getKeyOrDefault(var2.p().a());
         } else if (var3 == class_1802.field_8137) {
            return this.getKeyOrDefault(var2.u().a());
         } else if (var3 == class_1802.field_8777) {
            return this.getKeyOrDefault(var2.v().a());
         } else if (var3 == class_1802.field_8161) {
            return this.getKeyOrDefault(var2.w().a());
         } else if (var3 == class_1802.field_8786) {
            return this.getKeyOrDefault(var2.x().a());
         } else {
            return var3 == class_1802.field_8450 ? this.getKeyOrDefault(var2.z().a()) : -1;
         }
      }
   }

   @Unique
   private int getKeyOrDefault(int var1) {
      return var1 <= 0 ? -1 : var1;
   }
}

package ru.pulse.mixin;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.EventBusService;
import pulse.DropItemEvent;
import pulse.ItemUseEvent;

@Mixin(class_636.class)
public class ClientPlayerInteractionManagerMixin {
   @Inject(method = "interactItem", at = @At("HEAD"), cancellable = true)
   private void onRightClick(class_1657 var1, class_1268 var2, CallbackInfoReturnable<class_1269> var3) {
      ItemUseEvent var4 = new ItemUseEvent(var1, var1.method_37908(), var2);
      EventBusService.EVENT_BUS.post(var4);
      if (var4.c()) {
         var3.setReturnValue(class_1269.field_5814);
      }
   }

   @Inject(method = "clickSlot", at = @At("HEAD"), cancellable = true)
   private void onClickSlot(int var1, int var2, int var3, class_1713 var4, class_1657 var5, CallbackInfo var6) {
      if (var4 == class_1713.field_7795) {
         int var7 = var2;
         if (var2 >= 0 && var2 < 9) {
            var7 = var2 + 27;
         } else if (var2 >= 36 && var2 < 45) {
            var7 = var2 - 36;
         } else if (var2 == 45) {
            var7 = 40;
         }

         boolean var8 = var3 == 1;
         DropItemEvent var9 = new DropItemEvent(var7, var8);
         EventBusService.EVENT_BUS.post(var9);
         if (var9.c()) {
            var6.cancel();
         }
      }
   }
}

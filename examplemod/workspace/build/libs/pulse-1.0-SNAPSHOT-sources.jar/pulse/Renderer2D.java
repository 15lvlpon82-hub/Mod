package pulse;

import java.awt.Color;
import net.minecraft.class_1041;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

public interface Renderer2D {
   default void a(float var1, float var2, float var3, float var4, Color var5, class_4587 var6) {
      this.a(var1, var2, var3, var4, 0.0F, var5, var6);
   }

   void a(float var1, float var2, float var3, float var4, float var5, Color var6, class_4587 var7);

   default void a(float var1, float var2, float var3, float var4, float var5, Color var6, Color var7, Color var8, Color var9, class_4587 var10) {
      this.a(var1, var2, var3, var4, var5, var5, var5, var5, var6, var7, var8, var9, var10);
   }

   void a(
      float var1,
      float var2,
      float var3,
      float var4,
      float var5,
      float var6,
      float var7,
      float var8,
      Color var9,
      Color var10,
      Color var11,
      Color var12,
      class_4587 var13
   );

   void a(float var1, float var2, float var3, Color var4, class_4587 var5);

   void a(float var1, float var2, float var3, float var4, float var5, float var6, Color var7, class_4587 var8);

   default void b(float var1, float var2, float var3, float var4, float var5, Color var6, class_4587 var7) {
      this.b(var1, var2, var3, var4, 0.0F, var5, var6, var7);
   }

   void a(float var1, float var2, float var3, float var4, class_4587 var5);

   class_1041 a();

   void b(float var1, float var2, float var3, float var4, float var5, float var6, Color var7, class_4587 var8);

   void a(int var1, float var2, float var3, float var4, float var5, Color var6, class_4587 var7);

   void a(class_2960 var1, float var2, float var3, float var4, float var5, Color var6, class_4587 var7);

   default void a(class_2960 var1, float var2, float var3, float var4, float var5, float var6, Color var7, class_4587 var8) {
      this.a(var1, var2, var3, var4, var5, var6, 0.0F, 0.0F, 1.0F, 1.0F, var7, var8);
   }

   void a(
      class_2960 var1,
      float var2,
      float var3,
      float var4,
      float var5,
      float var6,
      float var7,
      float var8,
      float var9,
      float var10,
      Color var11,
      class_4587 var12
   );

   default Color a(Color var1, float var2) {
      return new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), class_3532.method_15340((int)(var2 * 255.0F), 0, 255));
   }

   default Color a(Color var1, int var2) {
      return new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), class_3532.method_15340(var2, 0, 255));
   }

   void b(float var1, float var2, float var3, float var4, class_4587 var5);

   default void a(float var1, float var2, float var3, float var4, float var5, class_4587 var6) {
      this.b(var1, var2, var3, var4, var6);
   }

   void a(class_4587 var1);

   ScissorStack b();

   void a(float var1, float var2, float var3, float var4, float var5, float var6, class_4587 var7);

   void c(float var1, float var2, float var3, float var4, class_4587 var5);

   void a(float var1, class_4587 var2);
}

package ru.pulse.mixin.accessor;

import net.minecraft.class_2645;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2645.class)
public interface CloseScreenS2CPacketAccessor {
   @Accessor("syncId")
   int getSyncId();
}

package ru.pulse.mixin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2663;
import net.minecraft.class_2678;
import net.minecraft.class_2703;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.EventBusService;
import pulse.GameJoinEvent;
import pulse.WorldClearEvent;
import pulse.TotemPopEvent;
import pulse.PlayerListCache;

@Mixin(class_634.class)
public class MixinClientPlayNetworkHandler {
   private static final Map<UUID, class_1799> cachedTotems = new HashMap<>();

   @Inject(method = "onEntityStatus", at = @At("HEAD"))
   private void onEntityStatus(class_2663 var1, CallbackInfo var2) {
      if (var1.method_11470() == 35 && var1.method_11469(class_310.method_1551().field_1687) instanceof class_1309 var4) {
         class_1799 var5 = this.getCachedTotem(var4);
         EventBusService.EVENT_BUS.post(new TotemPopEvent(var4, var5));
      }
   }

   private class_1799 getCachedTotem(class_1309 var1) {
      UUID var2 = var1.method_5667();
      class_1799 var3 = var1.method_6047();
      class_1799 var4 = var1.method_6079();
      class_1799 var5 = null;
      if (var3.method_7909() == class_1802.field_8288) {
         var5 = var3.method_7972();
      } else if (var4.method_7909() == class_1802.field_8288) {
         var5 = var4.method_7972();
      }

      if (var5 != null) {
         cachedTotems.put(var2, var5);
         return var5;
      } else {
         class_1799 var6 = cachedTotems.remove(var2);
         return var6 != null ? var6 : new class_1799(class_1802.field_8288);
      }
   }

   @Inject(method = "onPlayerList", at = @At("RETURN"))
   private void onPlayerList(class_2703 var1, CallbackInfo var2) {
      PlayerListCache.c().a(var1);
   }

   @Inject(method = "onGameJoin", at = @At("TAIL"))
   public void onGameJoin(class_2678 var1, CallbackInfo var2) {
      EventBusService.EVENT_BUS.post(new GameJoinEvent());
      PlayerListCache.c().a();
   }

   @Inject(method = "clearWorld", at = @At("HEAD"))
   public void onClearWorld(CallbackInfo var1) {
      cachedTotems.clear();
      PlayerListCache.c().b();
      EventBusService.EVENT_BUS.post(new WorldClearEvent());
   }
}

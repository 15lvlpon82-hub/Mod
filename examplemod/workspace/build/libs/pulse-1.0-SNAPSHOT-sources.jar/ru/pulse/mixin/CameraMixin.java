package ru.pulse.mixin;


import pulse.module.ModuleRegistry;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_5498;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.FreeLook;
import pulse.PerspectiveDistanceAnimation;
import pulse.Animations;

@Mixin(class_4184.class)
public abstract class CameraMixin {
   @Shadow
   protected abstract void setRotation(float var1, float var2);

   @Inject(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V", ordinal = 0, shift = Shift.AFTER))
   public void onUpdate(class_1922 var1, class_1297 var2, boolean var3, boolean var4, float var5, CallbackInfo var6) {
      if (FreeLook.active && var2 instanceof class_746) {
         this.setRotation(FreeLook.cameraYaw, FreeLook.cameraPitch);
      }
   }

   @Unique
   private boolean isPerspectiveAnimationEnabled() {
      return ModuleRegistry.ANIMATIONS != null && ModuleRegistry.ANIMATIONS.k() && ModuleRegistry.ANIMATIONS.i.a();
   }

   @Inject(method = "update", at = @At("HEAD"))
   private void onUpdateHead(class_1922 var1, class_1297 var2, boolean var3, boolean var4, float var5, CallbackInfo var6) {
      if (this.isPerspectiveAnimationEnabled()) {
         PerspectiveDistanceAnimation var7 = Animations.q();
         var7.a(var3, (long)(ModuleRegistry.ANIMATIONS.j.k() * 1.5F));
         var7.a();
      }
   }

   @ModifyArg(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;clipToSpace(F)F"), index = 0)
   private float modifyCameraDistance(float var1) {
      if (this.isPerspectiveAnimationEnabled()) {
         class_310 var2 = class_310.method_1551();
         if (var2.field_1690.method_31044() != class_5498.field_26664) {
            return Animations.q().b();
         }
      }

      return var1;
   }
}

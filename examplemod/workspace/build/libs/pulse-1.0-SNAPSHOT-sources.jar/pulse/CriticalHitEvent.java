package pulse;

import net.minecraft.class_1297;

public class CriticalHitEvent extends PulseEvent {
   private final class_1297 entity;

   public CriticalHitEvent(class_1297 entity) {
      this.entity = entity;
   }

   public class_1297 getEntity() {
      return this.entity;
   }

   public class_1297 a() {
      return this.entity;
   }
}


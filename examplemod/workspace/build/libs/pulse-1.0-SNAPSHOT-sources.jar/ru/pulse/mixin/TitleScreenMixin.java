package ru.pulse.mixin;

import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.pulse.Pulse;

@Mixin(class_442.class)
public class TitleScreenMixin {
   @Inject(method = "init", at = @At("TAIL"))
   private void onInit(CallbackInfo var1) {
      Pulse.checkAndShowUpdate((class_442)(Object)this);
   }
}

package ru.pulse.mixin;

import net.minecraft.class_276;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.CustomHandShaderCapture;

@Mixin(class_276.class)
public class FramebufferMixin {
   @Inject(method = "beginWrite", at = @At("HEAD"), cancellable = true)
   private void redirectToHandFramebuffer(boolean var1, CallbackInfo var2) {
      if (!CustomHandShaderCapture.guiOpen()) {
         if (CustomHandShaderCapture.isActive()) {
            class_310 var3 = class_310.method_1551();
            if (var3 != null) {
               class_276 var4 = var3.method_1522();
               if (var4 != null) {
                  if ((Object)this == var4) {
                     class_276 var5 = CustomHandShaderCapture.getFramebuffer();
                     if (var5 != null && var5 != var4) {
                        var5.method_1235(var1);
                        var2.cancel();
                     }
                  }
               }
            }
         }
      }
   }
}

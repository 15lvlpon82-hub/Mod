package ru.pulse.mixin;

import net.minecraft.class_1011;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import pulse.NativeImagePointerAccessor;

@Mixin(class_1011.class)
public class NativeImageMixin implements NativeImagePointerAccessor {
   @Shadow
   private long pointer;

   @Override
   public long pointer() {
      return this.pointer;
   }
}

package ru.pulse.mixin;


import pulse.module.ModuleRegistry;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4603;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.RenderTweaks;

@Mixin(class_4603.class)
public class OverlayRendererMixin {
   @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true)
   private static void onRenderFireOverlay(class_4587 var0, class_4597 var1, CallbackInfo var2) {
      RenderTweaks var3 = ModuleRegistry.RENDER_TWEAKS;
      if (var3.p()) {
         var2.cancel();
      }
   }

   @Inject(method = "renderUnderwaterOverlay", at = @At("HEAD"), cancellable = true)
   private static void onRenderUnderwaterOverlay(class_310 var0, class_4587 var1, class_4597 var2, CallbackInfo var3) {
      if (ModuleRegistry.NO_FLUID.k()) {
         var3.cancel();
      }
   }
}

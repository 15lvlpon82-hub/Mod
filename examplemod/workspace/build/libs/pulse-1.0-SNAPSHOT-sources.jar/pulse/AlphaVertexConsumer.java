package pulse;

import net.minecraft.class_4588;

public class AlphaVertexConsumer implements class_4588 {
   private final class_4588 delegate;
   private final float alphaMultiplier;

   public AlphaVertexConsumer(class_4588 delegate, float alphaMultiplier) {
      this.delegate = delegate;
      this.alphaMultiplier = alphaMultiplier;
   }

   public class_4588 method_22912(float x, float y, float z) {
      this.delegate.method_22912(x, y, z);
      return this;
   }

   public class_4588 method_1336(int red, int green, int blue, int alpha) {
      this.delegate.method_1336(red, green, blue, (int)(alpha * this.alphaMultiplier));
      return this;
   }

   public class_4588 method_22913(float u, float v) {
      this.delegate.method_22913(u, v);
      return this;
   }

   public class_4588 method_60796(int u, int v) {
      this.delegate.method_60796(u, v);
      return this;
   }

   public class_4588 method_22921(int u, int v) {
      this.delegate.method_22921(u, v);
      return this;
   }

   public class_4588 method_22914(float x, float y, float z) {
      this.delegate.method_22914(x, y, z);
      return this;
   }
}

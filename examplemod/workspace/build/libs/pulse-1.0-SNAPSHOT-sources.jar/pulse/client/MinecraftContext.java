package pulse.client;

import net.minecraft.class_1041;
import net.minecraft.class_310;

public interface MinecraftContext {
   class_310 CLIENT = class_310.method_1551();
   class_1041 WINDOW = CLIENT.method_22683();

   class_310 c = CLIENT;
   class_1041 d = WINDOW;
}

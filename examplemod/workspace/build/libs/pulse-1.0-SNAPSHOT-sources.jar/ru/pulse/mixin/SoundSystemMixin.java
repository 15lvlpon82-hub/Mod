package ru.pulse.mixin;

import net.minecraft.class_1113;
import net.minecraft.class_1140;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import pulse.EventBusService;
import pulse.SoundPlayEvent;
import pulse.VolumeScaledSoundInstance;

@Mixin(class_1140.class)
public class SoundSystemMixin {
   @ModifyVariable(method = "play(Lnet/minecraft/client/sound/SoundInstance;)V", at = @At("HEAD"), argsOnly = true)
   private class_1113 modifySound(class_1113 var1) {
      if (var1 != null && !(var1 instanceof VolumeScaledSoundInstance)) {
         SoundPlayEvent var2 = new SoundPlayEvent(var1);
         EventBusService.EVENT_BUS.post(var2);
         if (var2.c()) {
            return null;
         } else {
            return var2.e() != 1.0F ? new VolumeScaledSoundInstance(var1, var2.e()) : var1;
         }
      } else {
         return var1;
      }
   }
}

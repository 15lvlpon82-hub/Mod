package ru.pulse.mixin;

import net.minecraft.class_10034;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.ArmorRenderState;

@Mixin(class_970.class)
public class ArmorFeatureRendererMixin {
   @Inject(
      method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/client/render/entity/state/BipedEntityRenderState;FF)V",
      at = @At("HEAD")
   )
   private void captureState(class_4587 var1, class_4597 var2, int var3, class_10034 var4, float var5, float var6, CallbackInfo var7) {
      ArmorRenderState.a(var4.field_53460);
   }

   @Inject(
      method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/client/render/entity/state/BipedEntityRenderState;FF)V",
      at = @At("RETURN")
   )
   private void clearState(class_4587 var1, class_4597 var2, int var3, class_10034 var4, float var5, float var6, CallbackInfo var7) {
      ArmorRenderState.b();
   }
}

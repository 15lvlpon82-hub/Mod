package pulse;

import net.minecraft.class_1309;

public class EntityJumpEvent extends PulseEvent {
   private final class_1309 entity;

   public EntityJumpEvent(class_1309 entity) {
      this.entity = entity;
   }

   public class_1309 entity() {
      return this.entity;
   }

   public class_1309 a() {
      return this.entity;
   }
}

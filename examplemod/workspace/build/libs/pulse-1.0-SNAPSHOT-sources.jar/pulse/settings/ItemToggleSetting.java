package pulse.settings;

import java.awt.Color;
import net.minecraft.class_1792;

public class ItemToggleSetting extends Setting<Boolean> {
   private final class_1792 item;
   private Color color;

   public ItemToggleSetting(String name, String description, class_1792 item, boolean value, Color color) {
      super(name, description, value);
      this.item = item;
      this.color = color;
   }

   public ItemToggleSetting(String name, class_1792 item, boolean value, Color color) {
      this(name, "", item, value, color);
   }

   public ItemToggleSetting(String name, class_1792 item, Color color) {
      this(name, "", item, false, color);
   }

   public boolean get() {
      return this.k();
   }

   public void set(boolean value) {
      super.a(value);
   }

   public void toggle() {
      this.set(!this.get());
   }

   public class_1792 item() {
      return this.item;
   }

   public Color color() {
      return this.color;
   }

   public int rgb() {
      return this.color.getRGB();
   }

   public void setColor(Color color) {
      this.color = color;
   }

   public boolean a() {
      return this.get();
   }

   public void a(boolean value) {
      this.set(value);
   }

   public void b() {
      this.toggle();
   }

   public class_1792 c() {
      return this.item();
   }

   public Color d() {
      return this.color();
   }

   public int e() {
      return this.rgb();
   }

   public void a(Color color) {
      this.setColor(color);
   }
}

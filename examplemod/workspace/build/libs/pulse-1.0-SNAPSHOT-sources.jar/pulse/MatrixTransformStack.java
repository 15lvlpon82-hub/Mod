package pulse;

import net.minecraft.class_4587;
import net.minecraft.class_7833;

public class MatrixTransformStack {
   private class_4587 matrices;

   public void a(class_4587 matrices) {
      this.matrices = matrices;
   }

   public void a() {
      this.matrices.method_22903();
   }

   public void b() {
      this.matrices.method_22909();
   }

   public class_4587 c() {
      return this.matrices;
   }

   public void a(float x, float y, float z) {
      this.matrices.method_46416(x, y, z);
   }

   public void b(float x, float y, float z) {
      this.matrices.method_22905(x, y, z);
   }

   public void a(float degrees) {
      this.matrices.method_22907(class_7833.field_40714.rotationDegrees(degrees));
   }

   public void b(float degrees) {
      this.matrices.method_22907(class_7833.field_40716.rotationDegrees(degrees));
   }

   public void c(float degrees) {
      this.matrices.method_22907(class_7833.field_40718.rotationDegrees(degrees));
   }

   public void c(float xDegrees, float yDegrees, float zDegrees) {
      if (zDegrees != 0.0F) {
         this.c(zDegrees);
      }

      if (yDegrees != 0.0F) {
         this.b(yDegrees);
      }

      if (xDegrees != 0.0F) {
         this.a(xDegrees);
      }
   }

   public void d(float xDegrees, float yDegrees, float zDegrees) {
      this.c(xDegrees, yDegrees, zDegrees);
   }

   public void d(float degrees) {
      this.a(degrees);
   }

   public void e(float degrees) {
      this.b(degrees);
   }

   public void f(float degrees) {
      this.c(degrees);
   }
}

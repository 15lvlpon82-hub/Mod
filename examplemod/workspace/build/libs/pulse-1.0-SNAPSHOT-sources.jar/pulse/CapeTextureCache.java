package pulse;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2960;

public final class CapeTextureCache {
   private static final CapeTextureCache INSTANCE = new CapeTextureCache();

   private final Map<Integer, class_2960> texturesByUserId = new ConcurrentHashMap<>();

   private CapeTextureCache() {
   }

   public static CapeTextureCache getInstance() {
      return INSTANCE;
   }

   public void putCapeTexture(int userId, class_2960 texture) {
      if (texture == null) {
         texturesByUserId.remove(userId);
      } else {
         texturesByUserId.put(userId, texture);
      }
   }

   public class_2960 getCapeTexture(int userId) {
      return texturesByUserId.get(userId);
   }

   public void clear() {
      texturesByUserId.clear();
   }
}

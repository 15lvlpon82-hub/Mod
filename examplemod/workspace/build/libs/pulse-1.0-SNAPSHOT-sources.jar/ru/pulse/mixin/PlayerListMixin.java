package ru.pulse.mixin;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2678;
import net.minecraft.class_2703;
import net.minecraft.class_2703.class_2705;
import net.minecraft.class_2703.class_5893;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.EventBusService;
import pulse.PlayerJoinEvent;
import pulse.PlayerLeaveEvent;

@Mixin(class_634.class)
public class PlayerListMixin {
   @Unique
   private static final ConcurrentHashMap<UUID, String> uuidToNameCache = new ConcurrentHashMap<>();

   @Inject(method = "onPlayerList", at = @At("HEAD"))
   private void onPlayerListUpdate(class_2703 var1, CallbackInfo var2) {
      for (class_2705 var4 : var1.method_46329()) {
         UUID var5 = var4.comp_1106();
         if (var1.method_46327().contains(class_5893.field_29136) && var4.comp_1107() != null && var4.comp_1107().getName() != null) {
            String var6 = var4.comp_1107().getName();
            if (!uuidToNameCache.containsKey(var5)) {
               uuidToNameCache.put(var5, var6);
               EventBusService.EVENT_BUS.post(new PlayerJoinEvent(var6, var5));
            }
         }

         if (var1.method_46327().contains(class_5893.field_40700) && !var4.comp_1108()) {
            String var7 = uuidToNameCache.get(var5);
            if (var7 != null) {
               EventBusService.EVENT_BUS.post(new PlayerLeaveEvent(var7, var5));
               uuidToNameCache.remove(var5);
            } else {
               EventBusService.EVENT_BUS.post(new PlayerLeaveEvent("", var5));
            }
         }
      }
   }

   @Inject(method = "onGameJoin", at = @At("HEAD"))
   private void onGameJoin(class_2678 var1, CallbackInfo var2) {
      uuidToNameCache.clear();
   }
}

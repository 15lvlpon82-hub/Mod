package ru.pulse.mixin;


import pulse.module.ModuleRegistry;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_9779;
import net.minecraft.class_9909;
import net.minecraft.class_9922;
import net.minecraft.class_9958;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.EventBusService;
import pulse.WorldRenderStartEvent;
import pulse.WorldRenderEvent;

@Mixin(class_761.class)
public abstract class WorldRendererMixin {
   @Inject(method = "renderWeather", at = @At("HEAD"), cancellable = true)
   private void onRenderWeather(class_9909 var1, class_243 var2, float var3, class_9958 var4, CallbackInfo var5) {
      if (ModuleRegistry.RENDER_TWEAKS.n()) {
         var5.cancel();
      }
   }

   @Inject(method = "render", at = @At("HEAD"))
   private void preRender(
      class_9922 var1, class_9779 var2, boolean var3, class_4184 var4, class_757 var5, Matrix4f var6, Matrix4f var7, CallbackInfo var8
   ) {
      EventBusService.EVENT_BUS.post(new WorldRenderStartEvent(var2.method_60637(true)));
   }

   @Inject(method = "render", at = @At("RETURN"))
   private void postRenderEvent(
      class_9922 var1, class_9779 var2, boolean var3, class_4184 var4, class_757 var5, Matrix4f var6, Matrix4f var7, CallbackInfo var8
   ) {
      this.restoreRenderState();
      class_4587 var9 = new class_4587();
      var9.method_23760().method_23761().set(var6);
      EventBusService.EVENT_BUS.post(new WorldRenderEvent(var9, var2.method_60637(true)));
      this.restoreRenderState();
   }

   private void restoreRenderState() {
      RenderSystem.enableDepthTest();
      RenderSystem.depthFunc(515);
      RenderSystem.depthMask(true);
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
   }
}

package ru.pulse.mixin;

import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.EventBusService;
import pulse.ItemUseFinishEvent;

@Mixin(class_1799.class)
public class ItemStackMixin {
   @Inject(method = "finishUsing", at = @At("HEAD"))
   private void onItemUseFinish(class_1937 var1, class_1309 var2, CallbackInfoReturnable<class_1799> var3) {
      ItemUseFinishEvent var4 = new ItemUseFinishEvent((class_1799)(Object)this, var1, var2);
      EventBusService.EVENT_BUS.post(var4);
      if (var4.c()) {
         var3.cancel();
      }
   }
}

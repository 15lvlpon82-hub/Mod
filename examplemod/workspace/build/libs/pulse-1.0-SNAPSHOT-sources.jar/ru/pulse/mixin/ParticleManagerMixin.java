package ru.pulse.mixin;


import pulse.module.ModuleRegistry;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_702;
import net.minecraft.class_703;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.RenderTweaks;

@Mixin(class_702.class)
public class ParticleManagerMixin {
   @Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;", at = @At("HEAD"), cancellable = true)
   private void onAddParticle(
      class_2394 var1, double var2, double var4, double var6, double var8, double var10, double var12, CallbackInfoReturnable<class_703> var14
   ) {
      RenderTweaks var15 = ModuleRegistry.RENDER_TWEAKS;
      if (var15 != null
         && var15.u()
         && (
            var1.method_10295() == class_2398.field_11247
               || var1.method_10295() == class_2398.field_11238
               || var1.method_10295() == class_2398.field_11241
               || var1.method_10295() == class_2398.field_11243
               || var1.method_10295() == class_2398.field_11210
         )) {
         var14.setReturnValue(null);
      }
   }
}

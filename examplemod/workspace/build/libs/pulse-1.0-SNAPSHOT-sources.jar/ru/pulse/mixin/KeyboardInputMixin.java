package ru.pulse.mixin;

import net.minecraft.class_10185;
import net.minecraft.class_315;
import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.EventBusService;
import pulse.MovementInputEvent;

@Mixin(class_743.class)
public class KeyboardInputMixin extends class_744 {
   @Shadow
   @Final
   private class_315 settings;

   @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
   private void onTick(CallbackInfo var1) {
      this.field_54155 = new class_10185(
         this.settings.field_1894.method_1434(),
         this.settings.field_1881.method_1434(),
         this.settings.field_1913.method_1434(),
         this.settings.field_1849.method_1434(),
         this.settings.field_1903.method_1434(),
         this.settings.field_1832.method_1434(),
         this.settings.field_1867.method_1434()
      );
      this.field_3905 = getMovementMultiplier(this.field_54155.comp_3159(), this.field_54155.comp_3160());
      this.field_3907 = getMovementMultiplier(this.field_54155.comp_3161(), this.field_54155.comp_3162());
      MovementInputEvent var2 = new MovementInputEvent(this.field_3905, this.field_3907, this.field_54155.comp_3163(), this.field_54155.comp_3164(), 0.3F);
      EventBusService.EVENT_BUS.post(var2);
      if (var2.c()) {
         this.field_3905 = 0.0F;
         this.field_3907 = 0.0F;
         this.field_54155 = new class_10185(false, false, false, false, false, false, this.field_54155.comp_3165());
      } else {
         this.field_3905 = var2.d();
         this.field_3907 = var2.e();
         this.field_54155 = new class_10185(
            var2.d() > 0.0F, var2.d() < 0.0F, var2.e() > 0.0F, var2.e() < 0.0F, var2.f(), var2.g(), this.field_54155.comp_3165()
         );
      }

      var1.cancel();
   }

   @Unique
   private static float getMovementMultiplier(boolean var0, boolean var1) {
      if (var0 == var1) {
         return 0.0F;
      } else {
         return var0 ? 1.0F : -1.0F;
      }
   }
}

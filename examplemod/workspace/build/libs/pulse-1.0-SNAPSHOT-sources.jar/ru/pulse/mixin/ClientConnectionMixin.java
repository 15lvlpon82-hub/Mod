package ru.pulse.mixin;

import io.netty.channel.ChannelHandlerContext;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_7648;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.EventBusService;
import pulse.PacketEvent;

@Mixin(class_2535.class)
public class ClientConnectionMixin {
   @Inject(
      method = "channelRead0(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/network/packet/Packet;)V",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/network/ClientConnection;handlePacket(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/listener/PacketListener;)V"
      ),
      cancellable = true
   )
   private void onChannelRead(ChannelHandlerContext var1, class_2596<?> var2, CallbackInfo var3) {
      PacketEvent var4 = new PacketEvent(var2, PacketEvent.MessageDirection.RECIEVE);
      EventBusService.EVENT_BUS.post(var4);
      if (var4.c()) {
         var3.cancel();
      }
   }

   @Inject(method = "send(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/PacketCallbacks;)V", at = @At("HEAD"), cancellable = true)
   private void onSendPacket(class_2596<?> var1, class_7648 var2, CallbackInfo var3) {
      PacketEvent var4 = new PacketEvent(var1, PacketEvent.MessageDirection.SEND);
      EventBusService.EVENT_BUS.post(var4);
      if (var4.c()) {
         var3.cancel();
      }
   }
}

package ru.pulse.mixin;


import pulse.module.ModuleRegistry;
import net.minecraft.class_1291;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.RenderTweaks;

@Mixin(class_1309.class)
public class StatusEffectsMixin {
   @Inject(method = "hasStatusEffect", at = @At("HEAD"), cancellable = true)
   private void onHasStatusEffect(class_6880<class_1291> var1, CallbackInfoReturnable<Boolean> var2) {
      if ((Object)this instanceof class_746) {
         RenderTweaks var3 = ModuleRegistry.RENDER_TWEAKS;
         if (var3 != null && var1 == class_1294.field_5920 && var3.t()) {
            var2.setReturnValue(false);
         }
      }
   }
}

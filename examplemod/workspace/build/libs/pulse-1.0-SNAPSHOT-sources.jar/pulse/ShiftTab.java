package pulse;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_3675;
import pulse.module.ClientModule;
import pulse.module.ModuleCategory;
import pulse.module.ModuleInfo;
import pulse.settings.BooleanSetting;

@ModuleInfo(a = "Shift Tab", b = "Briefly sneaks while attacking.", c = ModuleCategory.UTILITIES)
public class ShiftTab extends ClientModule {
    private static final int SNEAK_TICKS = 2;
    private final BooleanSetting triggerBeforeAttack;
    private int sneakTicksLeft;
    private boolean restorePending;
    private boolean previousSneakPressed;

    public ShiftTab() {
        this.triggerBeforeAttack = new BooleanSetting(
            "Before Attack",
            "If disabled, sneaking starts after the attack event.",
            true
        );
    }

    @EventHandler
    public void a(CriticalHitEvent event) {
        if (this.triggerBeforeAttack.k()) {
            this.startSneakBurst();
        }
    }

    @EventHandler
    public void a(AttackEntityEvent event) {
        if (!this.triggerBeforeAttack.k()) {
            this.startSneakBurst();
        }
    }

    @EventHandler
    public void a(ClientTickEvent event) {
        if (c.field_1724 == null) {
            return;
        }

        if (this.sneakTicksLeft > 0) {
            c.field_1690.field_1832.method_23481(true);
            this.sneakTicksLeft--;
            return;
        }

        if (this.restorePending) {
            c.field_1690.field_1832.method_23481(this.previousSneakPressed);
            this.restorePending = false;
        }
    }

    @Override
    public void f() {
        super.f();
        this.sneakTicksLeft = 0;
        this.restorePending = false;
        if (c != null && c.field_1690 != null) {
            c.field_1690.field_1832.method_23481(this.isSneakKeyPhysicallyPressed());
        }
    }

    private void startSneakBurst() {
        if (c.field_1724 == null) {
            return;
        }

        this.previousSneakPressed = this.isSneakKeyPhysicallyPressed();
        this.sneakTicksLeft = SNEAK_TICKS;
        this.restorePending = true;
        c.field_1690.field_1832.method_23481(true);
    }

    private boolean isSneakKeyPhysicallyPressed() {
        return c != null
            && c.method_22683() != null
            && class_3675.method_15987(c.method_22683().method_4490(), c.field_1690.field_1832.method_1429().method_1444());
    }
}

package pulse;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import pulse.module.ClientModule;
import pulse.module.ModuleCategory;
import pulse.module.ModuleInfo;
import pulse.settings.BooleanSetting;
import pulse.settings.SliderSetting;

@ModuleInfo(a = "Healing Helper", b = "Highlights useful healing items.", c = ModuleCategory.UTILITIES)
public class HealingHelper extends ClientModule {
    private final BooleanSetting onlyWhenNeeded;
    private final SliderSetting healthThreshold;
    private final SliderSetting hungerThreshold;
    private final SliderSetting minimumPriority;
    private final Map<class_1792, Integer> itemPriority;

    public HealingHelper() {
        this.onlyWhenNeeded = new BooleanSetting("Only When Needed", true);
        this.healthThreshold = new SliderSetting("Health Threshold", 14.0F, 1.0F, 20.0F, 1.0F);
        this.hungerThreshold = new SliderSetting("Hunger Threshold", 15.0F, 1.0F, 20.0F, 1.0F);
        this.minimumPriority = new SliderSetting("Minimum Priority", 1.0F, 1.0F, 4.0F, 1.0F);

        Map<class_1792, Integer> priorities = new HashMap<>();
        priorities.put(class_1802.field_8574, 1);
        priorities.put(class_1802.field_8071, 2);
        priorities.put(class_1802.field_8463, 3);
        priorities.put(class_1802.field_8367, 4);
        this.itemPriority = Collections.unmodifiableMap(priorities);
    }

    public boolean a(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }

        int priority = this.a(stack.method_7909());
        if (priority < this.minimumPriority.b()) {
            return false;
        }

        return !this.onlyWhenNeeded.a() || this.shouldUseNow(stack.method_7909());
    }

    public List<class_1792> n() {
        return new ArrayList<>(this.itemPriority.keySet());
    }

    public int a(class_1792 item) {
        return this.itemPriority.getOrDefault(item, 0);
    }

    public BooleanSetting o() {
        return this.onlyWhenNeeded;
    }

    public SliderSetting p() {
        return this.healthThreshold;
    }

    public SliderSetting q() {
        return this.hungerThreshold;
    }

    public SliderSetting r() {
        return this.minimumPriority;
    }

    public Map<class_1792, Integer> s() {
        return this.itemPriority;
    }

    private boolean shouldUseNow(class_1792 item) {
        if (c.field_1724 == null) {
            return true;
        }

        if (item == class_1802.field_8071) {
            return c.field_1724.method_7344().method_7586() <= this.hungerThreshold.b();
        }

        return c.field_1724.method_6032() + c.field_1724.method_6067() <= this.healthThreshold.a();
    }
}

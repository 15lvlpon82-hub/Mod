package pulse;

import net.minecraft.class_1297;

public class AttackEntityEvent extends PulseEvent {
   private final class_1297 entity;

   public AttackEntityEvent(class_1297 entity) {
      this.entity = entity;
   }

   public class_1297 getEntity() {
      return this.entity;
   }

   public class_1297 a() {
      return this.entity;
   }
}


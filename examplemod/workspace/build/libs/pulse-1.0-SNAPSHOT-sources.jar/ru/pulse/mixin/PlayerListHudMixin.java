package ru.pulse.mixin;


import pulse.module.ModuleRegistry;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_10142;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2561.class_2562;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_355;
import net.minecraft.class_640;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import pulse.StreamerMode;
import pulse.IconTextureRegistry;
import pulse.PlayerListCache;

@Mixin(class_355.class)
public class PlayerListHudMixin {
   @Shadow
   @Final
   private class_310 client;
   @Shadow
   private class_2561 header;
   @Unique
   private static final int ICON_SIZE = 8;
   @Unique
   private static final int ICON_PADDING = 2;

   @Redirect(
      method = "render",
      at = @At(value = "FIELD", target = "Lnet/minecraft/client/gui/hud/PlayerListHud;header:Lnet/minecraft/text/Text;", opcode = 180)
   )
   private class_2561 getModifiedHeader(class_355 var1) {
      StreamerMode var2 = ModuleRegistry.STREAMER_MODE;
      if (var2.k() && var2.hideServerNumber.k() && this.header != null) {
         String var3 = this.header.getString();
         if (var3.contains("Анархия-")) {
            try {
               class_310 var4 = class_310.method_1551();
               String var5 = class_2562.method_10867(this.header, var4.method_1562().method_29091());
               String var6 = var5.replaceAll("Анархия-\\d+", "Анархия-***");
               return class_2562.method_10877(var6, var4.method_1562().method_29091());
            } catch (Exception var7) {
               return class_2561.method_43470(var3.replaceAll("Анархия-\\d+", "Анархия-***"));
            }
         }
      }

      return this.header;
   }

   @Redirect(
      method = "render",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/DrawContext;drawTextWithShadow(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/Text;III)I"
      )
   )
   private int redirectDrawTextWithShadow(class_332 var1, class_327 var2, class_2561 var3, int var4, int var5, int var6) {
      String var7 = this.extractPlayerNameFromText(var3.getString());
      if (var7 != null && PlayerListCache.c().a(var7)) {
         this.renderIcon(var1, var4, var5);
         return var1.method_27535(var2, var3, var4 + 8 + 2, var5, var6);
      } else {
         return var1.method_27535(var2, var3, var4, var5, var6);
      }
   }

   @Unique
   private String extractPlayerNameFromText(String var1) {
      if (var1 != null && !var1.isEmpty()) {
         if (this.client.field_1724 != null && this.client.field_1724.field_3944 != null) {
            for (class_640 var4 : this.client.field_1724.field_3944.method_45732().stream().toList()) {
               if (var4.method_2966() != null && var4.method_2966().getName() != null) {
                  String var5 = var4.method_2966().getName();
                  if (var1.contains(var5)) {
                     return var5;
                  }
               }
            }

            return null;
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   @Unique
   private void renderIcon(class_332 var1, int var2, int var3) {
      class_2960 var4 = IconTextureRegistry.get("logo");
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(class_10142.field_53879);
      RenderSystem.setShaderTexture(0, var4);
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      var1.method_25290(class_1921::method_62277, var4, var2, var3, 0.0F, 0.0F, 8, 8, 8, 8);
      RenderSystem.disableBlend();
   }
}

package pulse;

import net.minecraft.class_1113;

public class SoundPlayEvent extends CancellablePulseEvent {
   private final class_1113 sound;
   private float volume;
   private float pitch;

   public SoundPlayEvent(class_1113 sound) {
      this.sound = sound;
      try {
         this.volume = sound.method_4781();
         this.pitch = sound.method_4782();
      } catch (NullPointerException ignored) {
         this.volume = 1.0F;
         this.pitch = 1.0F;
      }
   }

   public class_1113 sound() {
      return this.sound;
   }

   public float volume() {
      return this.volume;
   }

   public void setVolume(float volume) {
      this.volume = volume;
   }

   public float pitch() {
      return this.pitch;
   }

   public void setPitch(float pitch) {
      this.pitch = pitch;
   }

   public class_1113 d() {
      return this.sound;
   }

   public float e() {
      return this.volume;
   }

   public void a(float volume) {
      this.volume = volume;
   }

   public float f() {
      return this.pitch;
   }

   public void b(float pitch) {
      this.pitch = pitch;
   }
}

package ru.pulse.mixin;


import pulse.module.ModuleRegistry;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.minecraft.class_10142;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4587.class_4665;
import net.minecraft.class_4588;
import net.minecraft.class_898;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.HitboxCustomizer;

@Mixin(class_898.class)
public class EntityHitboxMixin {
   @Inject(method = "renderHitbox", at = @At("HEAD"), cancellable = true)
   private static void renderCustomHitbox(class_4587 var0, class_4588 var1, class_1297 var2, float var3, float var4, float var5, float var6, CallbackInfo var7) {
      HitboxCustomizer var8 = ModuleRegistry.HITBOX_CUSTOMIZER;
      if (var8.k()) {
         class_310 var9 = class_310.method_1551();
         if (var9.field_1724 == null || !var9.field_1724.method_6059(class_1294.field_5919)) {
            class_238 var10 = var2.method_5829().method_989(-var2.method_23317(), -var2.method_23318(), -var2.method_23321());
            if (var8.o()) {
               renderFilledBox(var0, var10, var8);
            }

            renderHitboxOutline(var0, var1, var10, var8);
            if (var8.n() && var2 instanceof class_1309) {
               renderEyeLine(var0, var1, var2, var3, var8);
            }

            var7.cancel();
         }
      }
   }

   private static void renderFilledBox(class_4587 var0, class_238 var1, HitboxCustomizer var2) {
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(class_10142.field_53876);
      RenderSystem.enableDepthTest();
      RenderSystem.depthFunc(515);
      RenderSystem.disableCull();
      class_289 var3 = class_289.method_1348();
      class_287 var4 = var3.method_60827(class_5596.field_27382, class_290.field_1576);
      Color var5 = var2.p();
      int var6 = var5.getRed();
      int var7 = var5.getGreen();
      int var8 = var5.getBlue();
      byte var9 = 64;
      Matrix4f var10 = var0.method_23760().method_23761();
      float var11 = (float)var1.field_1323;
      float var12 = (float)var1.field_1322;
      float var13 = (float)var1.field_1321;
      float var14 = (float)var1.field_1320;
      float var15 = (float)var1.field_1325;
      float var16 = (float)var1.field_1324;
      var4.method_22918(var10, var11, var12, var13).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var11, var15, var13).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var14, var15, var13).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var14, var12, var13).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var14, var12, var16).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var14, var15, var16).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var11, var15, var16).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var11, var12, var16).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var11, var12, var13).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var11, var12, var16).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var11, var15, var16).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var11, var15, var13).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var14, var15, var13).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var14, var15, var16).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var14, var12, var16).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var14, var12, var13).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var11, var12, var13).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var14, var12, var13).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var14, var12, var16).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var11, var12, var16).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var11, var15, var16).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var14, var15, var16).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var14, var15, var13).method_1336(var6, var7, var8, var9);
      var4.method_22918(var10, var11, var15, var13).method_1336(var6, var7, var8, var9);
      class_286.method_43433(var4.method_60800());
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
   }

   private static void renderHitboxOutline(class_4587 var0, class_4588 var1, class_238 var2, HitboxCustomizer var3) {
      if (var3.q()) {
         renderCornerOutline(var0, var1, var2, var3);
      } else {
         renderFullOutline(var0, var1, var2, var3);
      }
   }

   private static void renderFullOutline(class_4587 var0, class_4588 var1, class_238 var2, HitboxCustomizer var3) {
      class_4665 var4 = var0.method_23760();
      Color var5 = var3.p();
      float var6 = var5.getRed() / 255.0F;
      float var7 = var5.getGreen() / 255.0F;
      float var8 = var5.getBlue() / 255.0F;
      float var9 = 1.0F;
      var1.method_56824(var4, (float)var2.field_1323, (float)var2.field_1322, (float)var2.field_1321)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, 1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, (float)var2.field_1320, (float)var2.field_1322, (float)var2.field_1321)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, 1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, (float)var2.field_1320, (float)var2.field_1322, (float)var2.field_1321)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, 0.0F, 1.0F, 0.0F);
      var1.method_56824(var4, (float)var2.field_1320, (float)var2.field_1325, (float)var2.field_1321)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, 0.0F, 1.0F, 0.0F);
      var1.method_56824(var4, (float)var2.field_1320, (float)var2.field_1325, (float)var2.field_1321)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, -1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, (float)var2.field_1323, (float)var2.field_1325, (float)var2.field_1321)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, -1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, (float)var2.field_1323, (float)var2.field_1325, (float)var2.field_1321)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, 0.0F, -1.0F, 0.0F);
      var1.method_56824(var4, (float)var2.field_1323, (float)var2.field_1322, (float)var2.field_1321)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, 0.0F, -1.0F, 0.0F);
      var1.method_56824(var4, (float)var2.field_1323, (float)var2.field_1322, (float)var2.field_1324)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, 1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, (float)var2.field_1320, (float)var2.field_1322, (float)var2.field_1324)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, 1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, (float)var2.field_1320, (float)var2.field_1322, (float)var2.field_1324)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, 0.0F, 1.0F, 0.0F);
      var1.method_56824(var4, (float)var2.field_1320, (float)var2.field_1325, (float)var2.field_1324)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, 0.0F, 1.0F, 0.0F);
      var1.method_56824(var4, (float)var2.field_1320, (float)var2.field_1325, (float)var2.field_1324)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, -1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, (float)var2.field_1323, (float)var2.field_1325, (float)var2.field_1324)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, -1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, (float)var2.field_1323, (float)var2.field_1325, (float)var2.field_1324)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, 0.0F, -1.0F, 0.0F);
      var1.method_56824(var4, (float)var2.field_1323, (float)var2.field_1322, (float)var2.field_1324)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, 0.0F, -1.0F, 0.0F);
      var1.method_56824(var4, (float)var2.field_1323, (float)var2.field_1322, (float)var2.field_1321)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, 0.0F, 0.0F, 1.0F);
      var1.method_56824(var4, (float)var2.field_1323, (float)var2.field_1322, (float)var2.field_1324)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, 0.0F, 0.0F, 1.0F);
      var1.method_56824(var4, (float)var2.field_1320, (float)var2.field_1322, (float)var2.field_1321)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, 0.0F, 0.0F, 1.0F);
      var1.method_56824(var4, (float)var2.field_1320, (float)var2.field_1322, (float)var2.field_1324)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, 0.0F, 0.0F, 1.0F);
      var1.method_56824(var4, (float)var2.field_1320, (float)var2.field_1325, (float)var2.field_1321)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, 0.0F, 0.0F, 1.0F);
      var1.method_56824(var4, (float)var2.field_1320, (float)var2.field_1325, (float)var2.field_1324)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, 0.0F, 0.0F, 1.0F);
      var1.method_56824(var4, (float)var2.field_1323, (float)var2.field_1325, (float)var2.field_1321)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, 0.0F, 0.0F, 1.0F);
      var1.method_56824(var4, (float)var2.field_1323, (float)var2.field_1325, (float)var2.field_1324)
         .method_22915(var6, var7, var8, var9)
         .method_60831(var4, 0.0F, 0.0F, 1.0F);
   }

   private static void renderCornerOutline(class_4587 var0, class_4588 var1, class_238 var2, HitboxCustomizer var3) {
      class_4665 var4 = var0.method_23760();
      Color var5 = var3.p();
      float var6 = var5.getRed() / 255.0F;
      float var7 = var5.getGreen() / 255.0F;
      float var8 = var5.getBlue() / 255.0F;
      float var9 = 1.0F;
      float var10 = var3.r();
      float var11 = (float)var2.field_1323;
      float var12 = (float)var2.field_1322;
      float var13 = (float)var2.field_1321;
      float var14 = (float)var2.field_1320;
      float var15 = (float)var2.field_1325;
      float var16 = (float)var2.field_1324;
      var1.method_56824(var4, var11, var12, var13).method_22915(var6, var7, var8, var9).method_60831(var4, 1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, var11 + var10, var12, var13).method_22915(var6, var7, var8, var9).method_60831(var4, 1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, var11, var12, var13).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F);
      var1.method_56824(var4, var11, var12 + var10, var13).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F);
      var1.method_56824(var4, var11, var12, var13).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 0.0F, 1.0F);
      var1.method_56824(var4, var11, var12, var13 + var10).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 0.0F, 1.0F);
      var1.method_56824(var4, var14, var12, var13).method_22915(var6, var7, var8, var9).method_60831(var4, -1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, var14 - var10, var12, var13).method_22915(var6, var7, var8, var9).method_60831(var4, -1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, var14, var12, var13).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F);
      var1.method_56824(var4, var14, var12 + var10, var13).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F);
      var1.method_56824(var4, var14, var12, var13).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 0.0F, 1.0F);
      var1.method_56824(var4, var14, var12, var13 + var10).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 0.0F, 1.0F);
      var1.method_56824(var4, var11, var15, var13).method_22915(var6, var7, var8, var9).method_60831(var4, 1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, var11 + var10, var15, var13).method_22915(var6, var7, var8, var9).method_60831(var4, 1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, var11, var15, var13).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, -1.0F, 0.0F);
      var1.method_56824(var4, var11, var15 - var10, var13).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, -1.0F, 0.0F);
      var1.method_56824(var4, var11, var15, var13).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 0.0F, 1.0F);
      var1.method_56824(var4, var11, var15, var13 + var10).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 0.0F, 1.0F);
      var1.method_56824(var4, var14, var15, var13).method_22915(var6, var7, var8, var9).method_60831(var4, -1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, var14 - var10, var15, var13).method_22915(var6, var7, var8, var9).method_60831(var4, -1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, var14, var15, var13).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, -1.0F, 0.0F);
      var1.method_56824(var4, var14, var15 - var10, var13).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, -1.0F, 0.0F);
      var1.method_56824(var4, var14, var15, var13).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 0.0F, 1.0F);
      var1.method_56824(var4, var14, var15, var13 + var10).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 0.0F, 1.0F);
      var1.method_56824(var4, var11, var12, var16).method_22915(var6, var7, var8, var9).method_60831(var4, 1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, var11 + var10, var12, var16).method_22915(var6, var7, var8, var9).method_60831(var4, 1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, var11, var12, var16).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F);
      var1.method_56824(var4, var11, var12 + var10, var16).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F);
      var1.method_56824(var4, var11, var12, var16).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 0.0F, -1.0F);
      var1.method_56824(var4, var11, var12, var16 - var10).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 0.0F, -1.0F);
      var1.method_56824(var4, var14, var12, var16).method_22915(var6, var7, var8, var9).method_60831(var4, -1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, var14 - var10, var12, var16).method_22915(var6, var7, var8, var9).method_60831(var4, -1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, var14, var12, var16).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F);
      var1.method_56824(var4, var14, var12 + var10, var16).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 1.0F, 0.0F);
      var1.method_56824(var4, var14, var12, var16).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 0.0F, -1.0F);
      var1.method_56824(var4, var14, var12, var16 - var10).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 0.0F, -1.0F);
      var1.method_56824(var4, var11, var15, var16).method_22915(var6, var7, var8, var9).method_60831(var4, 1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, var11 + var10, var15, var16).method_22915(var6, var7, var8, var9).method_60831(var4, 1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, var11, var15, var16).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, -1.0F, 0.0F);
      var1.method_56824(var4, var11, var15 - var10, var16).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, -1.0F, 0.0F);
      var1.method_56824(var4, var11, var15, var16).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 0.0F, -1.0F);
      var1.method_56824(var4, var11, var15, var16 - var10).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 0.0F, -1.0F);
      var1.method_56824(var4, var14, var15, var16).method_22915(var6, var7, var8, var9).method_60831(var4, -1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, var14 - var10, var15, var16).method_22915(var6, var7, var8, var9).method_60831(var4, -1.0F, 0.0F, 0.0F);
      var1.method_56824(var4, var14, var15, var16).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, -1.0F, 0.0F);
      var1.method_56824(var4, var14, var15 - var10, var16).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, -1.0F, 0.0F);
      var1.method_56824(var4, var14, var15, var16).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 0.0F, -1.0F);
      var1.method_56824(var4, var14, var15, var16 - var10).method_22915(var6, var7, var8, var9).method_60831(var4, 0.0F, 0.0F, -1.0F);
   }

   private static void renderEyeLine(class_4587 var0, class_4588 var1, class_1297 var2, float var3, HitboxCustomizer var4) {
      class_4665 var5 = var0.method_23760();
      class_243 var6 = new class_243(0.0, var2.method_18381(var2.method_18376()), 0.0);
      class_243 var7 = var2.method_5828(var3);
      class_243 var8 = var6.method_1019(var7.method_1021(2.0));
      Color var9 = var4.p();
      float var10 = var9.getRed() / 255.0F;
      float var11 = var9.getGreen() / 255.0F;
      float var12 = var9.getBlue() / 255.0F;
      var1.method_56824(var5, (float)var6.field_1352, (float)var6.field_1351, (float)var6.field_1350)
         .method_22915(var10, var11, var12, 1.0F)
         .method_60831(var5, (float)var7.field_1352, (float)var7.field_1351, (float)var7.field_1350);
      var1.method_56824(var5, (float)var8.field_1352, (float)var8.field_1351, (float)var8.field_1350)
         .method_22915(var10, var11, var12, 1.0F)
         .method_60831(var5, (float)var7.field_1352, (float)var7.field_1351, (float)var7.field_1350);
   }
}

package pulse;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.platform.GlStateManager.class_4534;
import com.mojang.blaze3d.platform.GlStateManager.class_4535;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_10142;
import net.minecraft.class_276;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_6367;
import org.lwjgl.opengl.GL14;

public class FramebufferCapture {
   private static final class_310 a = class_310.method_1551();
   private static class_276 b = null;
   private static int c = 0;
   private static int d = 0;
   private static boolean e = false;
   private static float f = 0.0F;
   private static float g = 0.0F;
   private static float h = 0.0F;
   private static float i = 0.0F;

   public static void begin(float var0, float var1, float var2, float var3) {
      if (!e) {
         int var4 = a.method_22683().method_4489();
         int var5 = a.method_22683().method_4506();
         if (b == null || c != var4 || d != var5) {
            if (b != null) {
               b.method_1238();
            }

            b = new class_6367(var4, var5, true);
            b.method_1236(0.0F, 0.0F, 0.0F, 0.0F);
            c = var4;
            d = var5;
         }

         f = var0;
         g = var1;
         h = var2;
         i = var3;
         b.method_1230();
         b.method_1235(true);
         e = true;
      }
   }

   public static void end(Renderer2D var0, float var1, class_4587 var2) {
      if (e) {
         e = false;
         a.method_1522().method_1235(true);
         if (var1 > 0.001F) {
            drawCaptured(var1);
         }
      }
   }

   public static boolean isCapturing() {
      return e;
   }

   public static void applyBlendState() {
      if (e) {
         GL14.glBlendFuncSeparate(770, 771, 1, 771);
      } else {
         RenderSystem.defaultBlendFunc();
      }
   }

   private static void drawCaptured(float var0) {
      if (b != null) {
         RenderSystem.enableBlend();
         RenderSystem.blendFuncSeparate(class_4535.ONE, class_4534.ONE_MINUS_SRC_ALPHA, class_4535.ONE, class_4534.ONE_MINUS_SRC_ALPHA);
         GlStateManager._bindTexture(b.method_30277());
         RenderSystem.setShaderTexture(0, b.method_30277());
         RenderSystem.setShader(class_10142.field_53880);
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         float var1 = ScreenScale.d();
         float var2 = a.method_22683().method_4489();
         float var3 = a.method_22683().method_4506();
         float var4 = f * var1 / var2;
         float var5 = 1.0F - (g + i) * var1 / var3;
         float var6 = (f + h) * var1 / var2;
         float var7 = 1.0F - g * var1 / var3;
         int var8 = (int)(var0 * 255.0F);
         class_289 var9 = class_289.method_1348();
         class_287 var10 = var9.method_60827(class_5596.field_27382, class_290.field_1575);
         var10.method_22912(f, g, 0.0F).method_22913(var4, var7).method_1336(var8, var8, var8, var8);
         var10.method_22912(f, g + i, 0.0F).method_22913(var4, var5).method_1336(var8, var8, var8, var8);
         var10.method_22912(f + h, g + i, 0.0F).method_22913(var6, var5).method_1336(var8, var8, var8, var8);
         var10.method_22912(f + h, g, 0.0F).method_22913(var6, var7).method_1336(var8, var8, var8, var8);
         class_286.method_43433(var10.method_60800());
         GlStateManager._bindTexture(0);
         RenderSystem.defaultBlendFunc();
      }
   }

   public static void dispose() {
      if (b != null) {
         b.method_1238();
         b = null;
      }

      c = 0;
      d = 0;
      e = false;
   }
}

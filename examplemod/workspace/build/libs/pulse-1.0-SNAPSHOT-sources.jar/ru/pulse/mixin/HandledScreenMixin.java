package ru.pulse.mixin;


import pulse.module.ModuleRegistry;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_465;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.Cooldowns;
import pulse.FastSwap;
import pulse.KeyNameFormatter;
import pulse.ElapsedTimer;
import pulse.CooldownInfo;

@Mixin(class_465.class)
public class HandledScreenMixin {
   @Shadow
   protected int x;
   @Shadow
   protected int y;
   @Shadow
   @Nullable
   protected class_1735 focusedSlot;
   @Unique
   private ElapsedTimer scrollTime;

   @Unique
   private ElapsedTimer getScrollTime() {
      if (this.scrollTime == null) {
         this.scrollTime = new ElapsedTimer();
      }

      return this.scrollTime;
   }

   @Inject(method = "render", at = @At("TAIL"))
   private void renderItemBindsOverlay(class_332 var1, int var2, int var3, float var4, CallbackInfo var5) {
      class_465 var6 = (class_465)(Object)this;
      FastSwap var7 = ModuleRegistry.FAST_SWAP;
      boolean var8 = var7 != null && var7.E().k() && var7.k();
      Cooldowns var9 = ModuleRegistry.COOLDOWNS;
      class_327 var10 = class_310.method_1551().field_1772;

      for (class_1735 var12 : var6.method_17577().field_7761) {
         class_1799 var13 = var12.method_7677();
         if (!var13.method_7960()) {
            int var14 = this.getKey(var13, var7);
            boolean var15 = var9 != null && var9.k() && var9.n() && this.hasAnyCooldown(var13, var9);
            boolean var16 = var14 != -1 && var14 != 0;
            if (var15 || var16) {
               int var17 = var12.field_7873 + this.x;
               int var18 = var12.field_7872 + this.y;
               if (var16 && !var15 && var8) {
                  class_4587 var19 = var1.method_51448();
                  var19.method_22903();
                  var19.method_46416(0.0F, 0.0F, 300.0F);
                  String var20 = KeyNameFormatter.a(var14);
                  float var21 = var10.method_1727(var20);
                  float var22 = 14.0F;
                  float var23 = Math.min(1.0F, var22 / var21);
                  float var24 = var7.F().k();
                  float var25 = var23 * var24;
                  var19.method_22905(var25, var25, 1.0F);
                  var1.method_51433(var10, var20, (int)((var17 + 0.5F) / var25), (int)((var18 + 0.5F) / var25), 16777215, true);
                  var19.method_22909();
               }

               if (var15) {
                  CooldownInfo.ItemCooldownSnapshot var29 = CooldownInfo.a(class_310.method_1551().field_1724.method_7357(), var13.method_7909());
                  int var30;
                  int var31;
                  if (Cooldowns.a(var13) && var9.b(var13.method_7909())) {
                     float var33 = var9.a(var13.method_7909());
                     var30 = (int)Math.ceil(var33 * 18.5);
                     var31 = var33 <= 0.33F ? 65280 : (var33 <= 0.66F ? 16776960 : 16711680);
                  } else {
                     var30 = (int)Math.ceil(var29.b());
                     float var32 = var29.c();
                     var31 = var32 <= 0.33F ? 65280 : (var32 <= 0.66F ? 16776960 : 16711680);
                  }

                  class_4587 var34 = var1.method_51448();
                  var34.method_22903();
                  var34.method_46416(0.0F, 0.0F, 300.0F);
                  String var35 = String.valueOf(var30);
                  float var36 = var10.method_1727(var35);
                  float var37 = 14.0F;
                  float var26 = Math.min(1.0F, var37 / var36);
                  float var27 = var9.q().k();
                  float var28 = var26 * var27;
                  var34.method_22905(var28, var28, 1.0F);
                  var1.method_51433(var10, var35, (int)((var17 + 0.5F) / var28), (int)((var18 + 0.5F) / var28), var31, true);
                  var34.method_22909();
               }
            }
         }
      }

      this.handleItemScroller();
   }

   @Unique
   private void handleItemScroller() {
      if (ModuleRegistry.ITEM_SCROLLER.k()) {
         class_310 var1 = class_310.method_1551();
         if (var1.field_1724 != null && var1.field_1755 != null) {
            if (this.focusedSlot != null && this.focusedSlot.method_7681() && this.focusedSlot.method_7677().method_7909() != class_1802.field_8162) {
               long var2 = var1.method_22683().method_4490();
               boolean var4 = GLFW.glfwGetMouseButton(var2, 0) == 1;
               boolean var5 = GLFW.glfwGetKey(var2, 340) == 1;
               if (var4 && var5) {
                  long var6 = ModuleRegistry.ITEM_SCROLLER.delay.k().longValue();
                  if (this.getScrollTime().a(var6)) {
                     class_465 var8 = (class_465)(Object)this;
                     var1.field_1761.method_2906(var8.method_17577().field_7763, this.focusedSlot.field_7874, 0, class_1713.field_7794, var1.field_1724);
                     this.getScrollTime().b();
                  }
               }
            }
         }
      }
   }

   @Unique
   private boolean hasAnyCooldown(class_1799 var1, Cooldowns var2) {
      CooldownInfo.ItemCooldownSnapshot var3 = CooldownInfo.a(class_310.method_1551().field_1724.method_7357(), var1.method_7909());
      return var3.a() || Cooldowns.a(var1) && var2.b(var1.method_7909());
   }

   @Unique
   private int getKey(class_1799 var1, FastSwap var2) {
      if (var2 == null) {
         return -1;
      } else {
         class_1792 var3 = var1.method_7909();
         if (var3 == class_1802.field_22021) {
            return this.getKeyOrDefault(var2.q().a());
         } else if (var3 == class_1802.field_8551) {
            return this.getKeyOrDefault(var2.r().a());
         } else if (var3 == class_1802.field_8449) {
            int var4 = var2.s().a();
            return var4 > 0 ? var4 : this.getKeyOrDefault(var2.y().a());
         } else if (var3 == class_1802.field_8479) {
            return this.getKeyOrDefault(var2.t().a());
         } else if (var3 == class_1802.field_8233) {
            return this.getKeyOrDefault(var2.n().a());
         } else if (var3 == class_1802.field_8634) {
            return this.getKeyOrDefault(var2.o().a());
         } else if (var3 == class_1802.field_8574 && var2.a(var1)) {
            return this.getKeyOrDefault(var2.p().a());
         } else if (var3 == class_1802.field_8137) {
            return this.getKeyOrDefault(var2.u().a());
         } else if (var3 == class_1802.field_8777) {
            return this.getKeyOrDefault(var2.v().a());
         } else if (var3 == class_1802.field_8161) {
            return this.getKeyOrDefault(var2.w().a());
         } else if (var3 == class_1802.field_8786) {
            return this.getKeyOrDefault(var2.x().a());
         } else {
            return var3 == class_1802.field_8450 ? this.getKeyOrDefault(var2.z().a()) : -1;
         }
      }
   }

   @Unique
   private int getKeyOrDefault(int var1) {
      return var1 <= 0 ? -1 : var1;
   }
}

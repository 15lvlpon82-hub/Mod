package ru.pulse.mixin;



import pulse.module.ModuleRegistry;
import pulse.client.MinecraftContext;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_329;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import pulse.StreamerMode;

@Mixin(class_329.class)
public class ScoreboardMixin implements MinecraftContext {
   @Redirect(
      method = "renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/scoreboard/ScoreboardObjective;getDisplayName()Lnet/minecraft/text/Text;")
   )
   private class_2561 hideScoreboardTitle(class_266 var1) {
      StreamerMode var2 = ModuleRegistry.STREAMER_MODE;
      if (var2.k() && var2.hideServerNumber.k()) {
         if (c == null || c.method_1558() == null) {
            return class_2561.method_43470("pulsevisuals.pro");
         }

         String var3 = c.method_1558().field_3761.toLowerCase();
         if (!var3.contains("holyworld")) {
            return class_2561.method_43470("pulsevisuals.pro");
         }
      }

      return var1.method_1114();
   }
}

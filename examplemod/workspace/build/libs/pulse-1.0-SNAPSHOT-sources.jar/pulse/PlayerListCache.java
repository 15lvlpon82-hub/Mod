package pulse;

import java.util.Collection;
import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2703;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_640;

public final class PlayerListCache {
   private static final PlayerListCache INSTANCE = new PlayerListCache();

   private final Map<String, Integer> capeIdsByName = new ConcurrentHashMap<>();
   private final AccountServiceClient accountService = AccountServiceClient.A();
   private volatile String currentServer = "";

   private PlayerListCache() {
   }

   public static PlayerListCache c() {
      return INSTANCE;
   }

   public void a() {
      this.refreshServer();
      this.capeIdsByName.clear();
   }

   public void b() {
      this.currentServer = "";
      this.capeIdsByName.clear();
   }

   public void a(class_2703 packet) {
      this.refreshServer();
   }

   public boolean a(String playerName) {
      return this.b(playerName) != null;
   }

   public Integer b(String playerName) {
      if (playerName == null || playerName.isBlank()) {
         return null;
      }

      String key = normalize(playerName);
      Integer cachedCape = this.capeIdsByName.get(key);
      if (cachedCape != null) {
         return cachedCape;
      }

      Integer cape = this.a(playerName, this.e());
      if (cape != null) {
         this.capeIdsByName.put(key, cape);
      }
      return cape;
   }

   public Integer a(String playerName, String serverAddress) {
      if (playerName == null || playerName.isBlank()) {
         return null;
      }

      try {
         return this.accountService.c(playerName, serverAddress == null ? "" : serverAddress);
      } catch (RuntimeException ignored) {
         return null;
      }
   }

   private Collection<class_640> d() {
      class_310 client = class_310.method_1551();
      class_634 networkHandler = client.method_1562();
      return networkHandler == null ? Collections.emptyList() : networkHandler.method_45732();
   }

   private String e() {
      this.refreshServer();
      return this.currentServer;
   }

   private void refreshServer() {
      class_310 client = class_310.method_1551();
      this.currentServer = client.method_1558() == null ? "" : client.method_1558().field_3761;
   }

   private static String normalize(String playerName) {
      return playerName.toLowerCase(Locale.ROOT);
   }
}

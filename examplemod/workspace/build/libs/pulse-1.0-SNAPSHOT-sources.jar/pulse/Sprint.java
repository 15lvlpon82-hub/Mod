package pulse;

import meteordevelopment.orbit.EventHandler;
import pulse.module.ClientModule;
import pulse.module.ModuleCategory;
import pulse.module.ModuleInfo;

@ModuleInfo(a = "Sprint", b = "Automatically holds the sprint key.", c = ModuleCategory.UTILITIES)
public class Sprint extends ClientModule {
    @EventHandler
    public void a(ClientTickEvent event) {
        if (c.field_1724 != null) {
            c.field_1690.field_1867.method_23481(c.field_1724.field_6012 > 3);
        }
    }
}

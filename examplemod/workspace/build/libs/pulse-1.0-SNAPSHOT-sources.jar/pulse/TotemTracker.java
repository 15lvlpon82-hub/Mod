package pulse;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import pulse.module.ClientModule;
import pulse.module.ModuleCategory;
import pulse.module.ModuleInfo;

@ModuleInfo(a = "Totem Tracker", b = "Tracks totem pops from recently attacked entities.", c = ModuleCategory.UTILITIES)
public class TotemTracker extends ClientModule {
    private static final long TARGET_MEMORY_MS = 5_000L;
    private final Map<UUID, ElapsedTimer> attackedTargets = new HashMap<>();
    private int lastNotificationAge = -1;

    @EventHandler
    public void a(AttackEntityEvent event) {
        if (c.field_1724 == null || !(event.a() instanceof class_1309 target) || target == c.field_1724) {
            return;
        }

        this.attackedTargets.put(target.method_5667(), new ElapsedTimer());
    }

    @EventHandler
    public void a(TotemPopEvent event) {
        if (c.field_1724 == null) {
            return;
        }

        class_1309 target = event.a();
        if (target == c.field_1724) {
            return;
        }

        ElapsedTimer timer = this.attackedTargets.get(target.method_5667());
        if (timer != null && !timer.hasElapsed(TARGET_MEMORY_MS)) {
            this.notifyTotemPop(target, event.b());
        }

        this.removeExpiredTargets();
    }

    private void notifyTotemPop(class_1309 target, class_1799 totemStack) {
        int playerAge = c.field_1724.field_6012;
        if (playerAge == this.lastNotificationAge) {
            return;
        }

        this.lastNotificationAge = playerAge;
        String targetName = target.method_5477().getString();
        String totemType = class_1890.method_57532(totemStack).method_57543() ? "regular" : "enchanted";
        ChatMessages.a((Object)("Totem Tracker: " + targetName + " popped a " + totemType + " totem."));
    }

    private void removeExpiredTargets() {
        this.attackedTargets.entrySet().removeIf(entry -> entry.getValue().hasElapsed(TARGET_MEMORY_MS));
    }

    @Override
    public void f() {
        super.f();
        this.attackedTargets.clear();
        this.lastNotificationAge = -1;
    }
}

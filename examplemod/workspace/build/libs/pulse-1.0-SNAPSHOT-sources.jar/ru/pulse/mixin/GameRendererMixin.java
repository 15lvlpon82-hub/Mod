package ru.pulse.mixin;


import pulse.module.ModuleRegistry;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.EventBusService;
import pulse.WorldRenderEndEvent;
import pulse.CustomHandShaderCapture;
import pulse.Zoom;
import pulse.AspectRatio;
import pulse.RenderTweaks;
import pulse.WorldToScreen;

@Mixin(class_757.class)
public abstract class GameRendererMixin {
   @Shadow
   private float zoom;
   @Shadow
   private float zoomX;
   @Shadow
   private float zoomY;

   @Shadow
   public abstract float getFarPlaneDistance();

   @Inject(method = "renderWorld", at = @At("HEAD"))
   private void onRenderWorldStart(class_9779 var1, CallbackInfo var2) {
   }

   @Inject(method = "renderHand", at = @At("RETURN"))
   private void onRenderHandEnd(class_4184 var1, float var2, Matrix4f var3, CallbackInfo var4) {
      CustomHandShaderCapture.endCapture();
   }

   @Inject(method = "renderWorld", at = @At("RETURN"))
   private void onRenderWorldEnd(class_9779 var1, CallbackInfo var2) {
      CustomHandShaderCapture.endCapture();
      class_4184 var3 = ((class_757)(Object)this).method_19418();
      EventBusService.EVENT_BUS.post(new WorldRenderEndEvent(new class_4587(), var1.method_60637(true), var3));
   }

   @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
   private void onBobViewWhenHurt(class_4587 var1, float var2, CallbackInfo var3) {
      RenderTweaks var4 = ModuleRegistry.RENDER_TWEAKS;
      if (var4.o()) {
         var3.cancel();
      }
   }

   @Inject(method = "showFloatingItem", at = @At("HEAD"), cancellable = true)
   private void onShowFloatingItem(CallbackInfo var1) {
      RenderTweaks var2 = ModuleRegistry.RENDER_TWEAKS;
      if (var2.q()) {
         var1.cancel();
      }
   }

   @Inject(method = "renderWorld", at = @At(value = "FIELD", target = "Lnet/minecraft/client/render/GameRenderer;renderHand:Z", opcode = 180, ordinal = 0))
   public void renderWorld(class_9779 var1, CallbackInfo var2) {
      if (CustomHandShaderCapture.guiOpen()) {
         CustomHandShaderCapture.resetForGui();
      } else {
         class_4184 var3 = class_310.method_1551().field_1773.method_19418();
         class_4587 var4 = new class_4587();
         Matrix4fStack var5 = RenderSystem.getModelViewStack();
         var5.pushMatrix();
         var5.mul(var4.method_23760().method_23761());
         var4.method_22907(class_7833.field_40714.rotationDegrees(var3.method_19329()));
         var4.method_22907(class_7833.field_40716.rotationDegrees(var3.method_19330() + 180.0F));
         WorldToScreen.a.set(RenderSystem.getProjectionMatrix());
         WorldToScreen.b.set(new Matrix4f(RenderSystem.getModelViewMatrix()));
         WorldToScreen.e.set(var4.method_23760().method_23761());
         var5.popMatrix();
         CustomHandShaderCapture.beginCapture();
      }
   }

   @Inject(method = "getBasicProjectionMatrix", at = @At("HEAD"), cancellable = true)
   public void getBasicProjectionMatrix(float var1, CallbackInfoReturnable<Matrix4f> var2) {
      if (Zoom.a) {
         var1 = (float)Zoom.b;
      }

      class_4587 var3 = new class_4587();
      var3.method_23760().method_23761().identity();
      if (this.zoom != 1.0F) {
         var3.method_22904(this.zoomX, -this.zoomY, 0.0);
         var3.method_22905(this.zoom, this.zoom, 1.0F);
      }

      float var4 = (float)class_310.method_1551().method_22683().method_4489() / class_310.method_1551().method_22683().method_4506();
      AspectRatio var5 = ModuleRegistry.ASPECT_RATIO;
      if (var5.k()) {
         var4 = var5.n();
      }

      var2.setReturnValue(var3.method_23760().method_23761().perspective(var1 * (float) (Math.PI / 180.0), var4, 0.05F, this.getFarPlaneDistance()));
   }
}

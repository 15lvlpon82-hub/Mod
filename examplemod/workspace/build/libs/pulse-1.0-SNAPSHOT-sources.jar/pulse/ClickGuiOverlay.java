package pulse;

import net.minecraft.class_4587;

public interface ClickGuiOverlay {
   void a(class_4587 matrices, Renderer2D renderer, float x, float y, int mouseX, int mouseY);

   void a(float x, float y, int mouseX, int mouseY);

   default void b(float x, float y, int mouseX, int mouseY) {
   }
}

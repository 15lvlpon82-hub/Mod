package pulse;

import net.minecraft.class_4184;
import net.minecraft.class_4587;

public class WorldRenderEndEvent extends PulseEvent {
   private final class_4587 matrices;
   private final float tickDelta;
   private final class_4184 camera;

   public WorldRenderEndEvent(class_4587 matrices, float tickDelta, class_4184 camera) {
      this.matrices = matrices;
      this.tickDelta = tickDelta;
      this.camera = camera;
   }

   public class_4587 matrices() {
      return this.matrices;
   }

   public float tickDelta() {
      return this.tickDelta;
   }

   public class_4184 camera() {
      return this.camera;
   }

   public class_4587 a() {
      return this.matrices;
   }

   public float b() {
      return this.tickDelta;
   }

   public class_4184 c() {
      return this.camera;
   }
}

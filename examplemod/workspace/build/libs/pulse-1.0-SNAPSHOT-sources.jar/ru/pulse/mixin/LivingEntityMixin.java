package ru.pulse.mixin;


import pulse.module.ModuleRegistry;
import net.minecraft.class_1291;
import net.minecraft.class_1292;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.EventBusService;
import pulse.EntityJumpEvent;
import pulse.PlayerDeathEvent;
import pulse.CustomHand;
import pulse.RenderTweaks;

@Mixin(class_1309.class)
public class LivingEntityMixin {
   @Overwrite
   private int getHandSwingDuration() {
      class_1309 var1 = (class_1309)(Object)this;
      if (class_1292.method_5576(var1)) {
         return 6 - (1 + class_1292.method_5575(var1));
      } else {
         CustomHand var2 = ModuleRegistry.CUSTOM_HAND;
         if (var2 != null && var2.k()) {
            int var3 = var2.animationSpeed.b();
            return var1.method_6059(class_1294.field_5901) ? var3 + (1 + var1.method_6112(class_1294.field_5901).method_5578()) * 2 : var3;
         } else {
            return var1.method_6059(class_1294.field_5901) ? 6 + (1 + var1.method_6112(class_1294.field_5901).method_5578()) * 2 : 6;
         }
      }
   }

   @Inject(method = "jump", at = @At("HEAD"))
   private void onJump(CallbackInfo var1) {
      class_1309 var2 = (class_1309)(Object)this;
      EventBusService.EVENT_BUS.post(new EntityJumpEvent(var2));
   }

   @Inject(method = "handleStatus", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;getDeathSound()Lnet/minecraft/sound/SoundEvent;"))
   public void handleStatus(byte var1, CallbackInfo var2) {
      class_1309 var3 = (class_1309)(Object)this;
      if (var3 instanceof class_746 var4) {
         PlayerDeathEvent var5 = new PlayerDeathEvent(var4, var4.method_23317(), var4.method_23318(), var4.method_23321());
         EventBusService.EVENT_BUS.post(var5);
      }
   }

   @Inject(method = "hasStatusEffect", at = @At("HEAD"), cancellable = true)
   private void onHasStatusEffect(class_6880<class_1291> var1, CallbackInfoReturnable<Boolean> var2) {
      if ((Object)this instanceof class_746) {
         RenderTweaks var3 = ModuleRegistry.RENDER_TWEAKS;
         if (var3 != null && var1 == class_1294.field_5920 && var3.t()) {
            var2.setReturnValue(false);
         }
      }
   }
}

package ru.pulse.mixin;


import pulse.client.MinecraftContext;
import net.minecraft.class_310;
import net.minecraft.class_310.class_5859;
import net.minecraft.class_434.class_9678;
import net.minecraft.class_542;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.EventBusService;
import pulse.AttackEntityEvent;
import pulse.WorldChangeEvent;
import pulse.RenderFrameTimer;
import ru.pulse.Pulse;

@Mixin(class_310.class)
public class MinecraftClientMixin implements MinecraftContext {
   @Inject(method = "joinWorld", at = @At("RETURN"))
   private void onWorldChange(class_638 var1, class_9678 var2, CallbackInfo var3) {
      EventBusService.EVENT_BUS.post(new WorldChangeEvent());
   }

   @Inject(
      method = "<init>",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/debug/DebugRenderer;<init>(Lnet/minecraft/client/MinecraftClient;)V")
   )
   public void init(class_542 var1, CallbackInfo var2) {
      Pulse.getInstance().init();
   }

   @Inject(method = "render", at = @At(value = "FIELD", target = "Lnet/minecraft/client/MinecraftClient;fpsCounter:I", opcode = 181, ordinal = 0))
   private void render(boolean var1, CallbackInfo var2) {
      try {
         Class.forName("ru.pulse.Pulse").getMethod("runtimeBrandingTick").invoke(null);
      } catch (Throwable var4) {
      }

      RenderFrameTimer.b();
   }

   @Inject(method = "isMultiplayerEnabled", at = @At("HEAD"), cancellable = true)
   public void allowsMultiplayer(CallbackInfoReturnable<Boolean> var1) {
      var1.setReturnValue(true);
   }

   @Inject(method = "getChatRestriction", at = @At("HEAD"), cancellable = true)
   public void allowsChat(CallbackInfoReturnable<class_5859> var1) {
      var1.setReturnValue(class_5859.field_28940);
   }

   @Inject(method = "isRealmsEnabled", at = @At("HEAD"), cancellable = true)
   public void allowsRealms(CallbackInfoReturnable<Boolean> var1) {
      var1.setReturnValue(false);
   }

   @Inject(
      method = "doAttack",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayerInteractionManager;attackEntity(Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/entity/Entity;)V"
      )
   )
   private void onAttack(CallbackInfoReturnable<Boolean> var1) {
      if (c.field_1692 != null) {
         EventBusService.EVENT_BUS.post(new AttackEntityEvent(c.field_1692));
      }
   }
}

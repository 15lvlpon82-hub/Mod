package pulse;

import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;

public class BlockOutlineEvent extends CancellablePulseEvent {
   private final class_4587 matrices;
   private final class_4588 vertexConsumer;
   private final class_1297 entity;
   private final double cameraX;
   private final double cameraY;
   private final double cameraZ;
   private final class_2338 blockPos;
   private final class_2680 blockState;

   public BlockOutlineEvent(
      class_4587 matrices,
      class_4588 vertexConsumer,
      class_1297 entity,
      double cameraX,
      double cameraY,
      double cameraZ,
      class_2338 blockPos,
      class_2680 blockState
   ) {
      this.matrices = matrices;
      this.vertexConsumer = vertexConsumer;
      this.entity = entity;
      this.cameraX = cameraX;
      this.cameraY = cameraY;
      this.cameraZ = cameraZ;
      this.blockPos = blockPos;
      this.blockState = blockState;
   }

   public class_4587 matrices() {
      return this.matrices;
   }

   public class_4588 vertexConsumer() {
      return this.vertexConsumer;
   }

   public class_1297 entity() {
      return this.entity;
   }

   public double cameraX() {
      return this.cameraX;
   }

   public double cameraY() {
      return this.cameraY;
   }

   public double cameraZ() {
      return this.cameraZ;
   }

   public class_2338 blockPos() {
      return this.blockPos;
   }

   public class_2680 blockState() {
      return this.blockState;
   }

   public class_4587 d() {
      return this.matrices;
   }

   public class_4588 e() {
      return this.vertexConsumer;
   }

   public class_1297 f() {
      return this.entity;
   }

   public double g() {
      return this.cameraX;
   }

   public double h() {
      return this.cameraY;
   }

   public double i() {
      return this.cameraZ;
   }

   public class_2338 j() {
      return this.blockPos;
   }

   public class_2680 k() {
      return this.blockState;
   }
}


package pulse;

import net.minecraft.class_4587;

public class HudRenderPreEvent extends PulseEvent {
   private final class_4587 matrices;
   private final int width;
   private final int height;
   private final float tickDelta;

   public HudRenderPreEvent(class_4587 matrices, int width, int height, float tickDelta) {
      this.matrices = matrices;
      this.width = width;
      this.height = height;
      this.tickDelta = tickDelta;
   }

   public class_4587 matrices() {
      return this.matrices;
   }

   public int width() {
      return this.width;
   }

   public int height() {
      return this.height;
   }

   public float tickDelta() {
      return this.tickDelta;
   }

   public class_4587 a() {
      return this.matrices;
   }

   public int b() {
      return this.width;
   }

   public int c() {
      return this.height;
   }

   public float d() {
      return this.tickDelta;
   }
}

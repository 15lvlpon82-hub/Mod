package ru.pulse.mixin;




import pulse.module.ModuleRegistry;
import pulse.client.MinecraftContext;
import pulse.module.ClientModule;
import net.minecraft.class_2338;
import net.minecraft.class_239.class_240;
import net.minecraft.class_243;
import net.minecraft.class_309;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.EventBusService;
import pulse.MapMarker;
import pulse.MarkerManager;
import pulse.MarkerSettings;
import pulse.KeyInputEvent;
import pulse.ClickGuiKeyBinding;
import pulse.GuiInput;
import pulse.Theme;
import pulse.PulseClickGuiScreen;
import pulse.GuiInteractionState;
import ru.pulse.Pulse;

@Mixin(class_309.class)
public class KeyboardMixin {
   @Shadow
   @Final
   private class_310 client;
   @Unique
   private static final double MAX_RAYCAST_DISTANCE = 500.0;

   @Inject(method = "onKey", at = @At("HEAD"))
   private void onKey(long var1, int var3, int var4, int var5, int var6, CallbackInfo var7) {
      if (var1 == this.client.method_22683().method_4490()) {
         EventBusService.EVENT_BUS.post(new KeyInputEvent(var3, var4, var5, var6));
         if (MinecraftContext.c.field_1724 == null || MinecraftContext.c.field_1687 == null) {
            return;
         }

         if (var5 != 1) {
            return;
         }

         if (MinecraftContext.c.field_1755 != null) {
            if (ClickGuiKeyBinding.OPEN_KEY.method_1417(var3, var4) && MinecraftContext.c.field_1755 instanceof PulseClickGuiScreen var11) {
               if (GuiInteractionState.a().b()) {
                  var11.c();
               } else {
                  GuiInput.j();
                  MinecraftContext.c.method_1507(null);
               }
            }

            return;
         }

         if (ClickGuiKeyBinding.OPEN_KEY.method_1417(var3, var4)) {
            MinecraftContext.c.method_1507(Pulse.getInstance().getClickGui());
            return;
         }

         int var8 = MarkerSettings.b();
         if (MarkerSettings.a() && var8 != 0 && var8 == var3) {
            this.createQuickMarker();
            return;
         }

         for (ClientModule var10 : ModuleRegistry.all()) {
            if (var10.j() == var3) {
               var10.d();
            }
         }
      }
   }

   @Unique
   private void createQuickMarker() {
      if (MinecraftContext.c.field_1724 != null && MinecraftContext.c.field_1687 != null) {
         class_243 var1 = MinecraftContext.c.field_1724.method_5836(1.0F);
         class_243 var2 = MinecraftContext.c.field_1724.method_5828(1.0F);
         class_243 var3 = var1.method_1019(var2.method_1021(500.0));
         class_3965 var4 = MinecraftContext.c.field_1687.method_17742(new class_3959(var1, var3, class_3960.field_17559, class_242.field_1348, MinecraftContext.c.field_1724));
         if (var4.method_17783() == class_240.field_1332) {
            class_2338 var5 = var4.method_17777();
            MapMarker var6 = new MapMarker("Р‘С‹СЃС‚СЂР°СЏ РјРµС‚РєР°", var5.method_10263(), var5.method_10264(), var5.method_10260(), Theme.X, MapMarker.Icon.FAST);
            MarkerManager.a(var6);
         }
      }
   }
}

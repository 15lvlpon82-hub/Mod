package ru.pulse.mixin;


import pulse.module.ModuleRegistry;
import net.minecraft.class_2561;
import net.minecraft.class_410;
import net.minecraft.class_4185;
import net.minecraft.class_424;
import net.minecraft.class_4325;
import net.minecraft.class_433;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_500;
import net.minecraft.class_642;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.PvpSafe;
import pulse.CombatState;

@Mixin(class_433.class)
public abstract class GameMenuScreenMixin extends class_437 {
   @Shadow
   @Nullable
   private class_4185 exitButton;

   protected GameMenuScreenMixin(class_2561 var1) {
      super(var1);
   }

   @Inject(method = "initWidgets", at = @At("TAIL"))
   private void onInitWidgets(CallbackInfo var1) {
      if (this.exitButton != null) {
         class_2561 var2 = this.exitButton.method_25369();
         int var3 = this.exitButton.method_46426();
         int var4 = this.exitButton.method_46427();
         int var5 = this.exitButton.method_25368();
         int var6 = this.exitButton.method_25364();
         this.method_37066(this.exitButton);
         this.exitButton = class_4185.method_46430(var2, var1x -> {
            var1x.field_22763 = false;
            PvpSafe var2x = ModuleRegistry.PVP_SAFE;
            if (var2x != null && var2x.k() && CombatState.a().a()) {
               this.field_22787.method_1507(new class_410(var1xx -> {
                  if (var1xx) {
                     this.performDisconnect();
                  } else {
                     this.field_22787.method_1507(this);
                  }
               }, class_2561.method_43470("Leave the server while PVP Safe is active?"), class_2561.method_43473()));
            } else {
               this.performDisconnect();
            }
         }).method_46434(var3, var4, var5, var6).method_46431();
         this.method_37063(this.exitButton);
      }
   }

   private void performDisconnect() {
      boolean var1 = this.field_22787.method_1542();
      class_642 var2 = this.field_22787.method_1558();
      if (this.field_22787.field_1687 != null) {
         this.field_22787.field_1687.method_8525();
      }

      if (var1) {
         this.field_22787.method_56134(new class_424(class_2561.method_43471("menu.savingLevel")));
      } else {
         this.field_22787.method_18099();
      }

      class_442 var3 = new class_442();
      if (var1) {
         this.field_22787.method_1507(var3);
      } else if (var2 != null && var2.method_52811()) {
         this.field_22787.method_1507(new class_4325(var3));
      } else {
         this.field_22787.method_1507(new class_500(var3));
      }
   }
}

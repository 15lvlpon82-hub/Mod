package pulse;

import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public class ItemUseFinishEvent extends CancellablePulseEvent {
   private final class_1799 stack;
   private final class_1937 world;
   private final class_1309 user;

   public ItemUseFinishEvent(class_1799 stack, class_1937 world, class_1309 user) {
      this.stack = stack;
      this.world = world;
      this.user = user;
   }

   public class_1799 stack() {
      return this.stack;
   }

   public class_1937 world() {
      return this.world;
   }

   public class_1309 user() {
      return this.user;
   }

   public class_1799 d() {
      return this.stack;
   }

   public class_1937 e() {
      return this.world;
   }

   public class_1309 f() {
      return this.user;
   }
}

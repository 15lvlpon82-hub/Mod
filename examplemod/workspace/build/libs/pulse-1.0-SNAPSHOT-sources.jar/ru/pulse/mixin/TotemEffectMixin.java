package ru.pulse.mixin;


import pulse.module.ModuleRegistry;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.RenderTweaks;

@Mixin(class_329.class)
public abstract class TotemEffectMixin {
   @Shadow
   @Final
   private class_310 client;
   @Final
   private static class_2960 TOTEM_OF_UNDYING_TEXTURE;
   @Shadow
   private int heldItemTooltipFade;
   @Shadow
   private class_1799 currentStack;

   @Inject(method = "renderHeldItemTooltip", at = @At("HEAD"), cancellable = true)
   private void onRenderHeldItemTooltip(class_332 var1, CallbackInfo var2) {
      RenderTweaks var3 = ModuleRegistry.RENDER_TWEAKS;
      if (var3.q() && this.heldItemTooltipFade > 0 && !this.currentStack.method_7960()) {
         var2.cancel();
      }
   }

   @Inject(method = "tick()V", at = @At("HEAD"))
   private void onTick(CallbackInfo var1) {
      RenderTweaks var2 = ModuleRegistry.RENDER_TWEAKS;
      if (var2.q() && this.heldItemTooltipFade > 0) {
         this.heldItemTooltipFade = 0;
      }
   }
}

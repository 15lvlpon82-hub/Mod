package ru.pulse.mixin.accessor;

import net.minecraft.class_2561;
import net.minecraft.class_355;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_355.class)
public interface PlayerListHudAccessor {
   @Accessor("header")
   class_2561 getHeader();

   @Accessor("footer")
   class_2561 getFooter();

   @Accessor("visible")
   boolean isVisible();

   @Accessor("visible")
   void setVisible(boolean var1);
}

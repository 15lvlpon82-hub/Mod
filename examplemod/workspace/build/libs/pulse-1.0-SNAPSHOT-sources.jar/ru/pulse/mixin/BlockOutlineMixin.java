package ru.pulse.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.BlockOutlineEvent;
import pulse.EventBusService;
import pulse.module.ModuleRegistry;

@Mixin(class_761.class)
public class BlockOutlineMixin {
   @Inject(method = "drawBlockOutline", at = @At("HEAD"), cancellable = true)
   private void onDrawBlockOutline(
      class_4587 matrices,
      class_4588 vertexConsumer,
      class_1297 entity,
      double cameraX,
      double cameraY,
      double cameraZ,
      class_2338 blockPos,
      class_2680 blockState,
      int color,
      CallbackInfo callbackInfo
   ) {
      if (ModuleRegistry.BLOCK_OVERLAY.k()) {
         BlockOutlineEvent event = new BlockOutlineEvent(matrices, vertexConsumer, entity, cameraX, cameraY, cameraZ, blockPos, blockState);
         EventBusService.EVENT_BUS.post(event);
         if (event.c()) {
            callbackInfo.cancel();
         }
      }
   }
}

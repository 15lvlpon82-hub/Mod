package ru.pulse.mixin;


import pulse.module.ModuleRegistry;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.minecraft.class_638;
import net.minecraft.class_6854;
import net.minecraft.class_758;
import net.minecraft.class_758.class_4596;
import net.minecraft.class_9958;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_758.class)
public class BackgroundRendererMixin {
   @Inject(method = "getFogColor", at = @At("RETURN"), cancellable = true)
   private static void customizeFogColor(class_4184 var0, float var1, class_638 var2, int var3, float var4, CallbackInfoReturnable<Vector4f> var5) {
      if (ModuleRegistry.WORLD_CUSTOMIZER.n()) {
         int var6 = ModuleRegistry.WORLD_CUSTOMIZER.s();
         float var7 = (var6 >> 16 & 0xFF) / 255.0F;
         float var8 = (var6 >> 8 & 0xFF) / 255.0F;
         float var9 = (var6 & 0xFF) / 255.0F;
         var5.setReturnValue(new Vector4f(var7, var8, var9, 1.0F));
      }
   }

   @Inject(method = "applyFog", at = @At("HEAD"), cancellable = true)
   private static void onApplyFog(class_4184 var0, class_4596 var1, Vector4f var2, float var3, boolean var4, float var5, CallbackInfoReturnable<class_9958> var6) {
      if (ModuleRegistry.NO_FLUID.k()) {
         class_5636 var7 = var0.method_19334();
         if (var7 == class_5636.field_27886 || var7 == class_5636.field_27885) {
            var6.setReturnValue(class_9958.field_53065);
         }
      }

      if (ModuleRegistry.WORLD_CUSTOMIZER.o()) {
         float var9 = ModuleRegistry.WORLD_CUSTOMIZER.p();
         float var8 = ModuleRegistry.WORLD_CUSTOMIZER.q();
         var6.setReturnValue(new class_9958(var9, var8, class_6854.field_36350, var2.x, var2.y, var2.z, var2.w));
      }
   }
}

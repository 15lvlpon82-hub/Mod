package pulse;

import net.minecraft.class_4587;
import org.joml.Quaternionf;

public final class ModelTransformApplier {
   private static final float MODEL_SCALE = 16.0F;

   private ModelTransformApplier() {
   }

   public static void translatePartOffset(ModelPart part, class_4587 matrices) {
      matrices.method_46416(-part.d() / MODEL_SCALE, part.e() / MODEL_SCALE, part.f() / MODEL_SCALE);
   }

   public static void translatePartPivot(ModelPart part, class_4587 matrices) {
      matrices.method_46416(part.j() / MODEL_SCALE, part.k() / MODEL_SCALE, part.l() / MODEL_SCALE);
   }

   public static void translatePartPivotBack(ModelPart part, class_4587 matrices) {
      matrices.method_46416(-part.j() / MODEL_SCALE, -part.k() / MODEL_SCALE, -part.l() / MODEL_SCALE);
   }

   public static void rotatePart(ModelPart part, class_4587 matrices) {
      if (part.c() != 0.0F) {
         matrices.method_22907(new Quaternionf().rotationZ(part.c()));
      }

      if (part.b() != 0.0F) {
         matrices.method_22907(new Quaternionf().rotationY(part.b()));
      }

      if (part.a() != 0.0F) {
         matrices.method_22907(new Quaternionf().rotationX(part.a()));
      }
   }

   public static void scalePart(ModelPart part, class_4587 matrices) {
      matrices.method_22905(part.g(), part.h(), part.i());
   }

   public static void translateCubePivot(ModelCube cube, class_4587 matrices) {
      matrices.method_46416(cube.c.a() / MODEL_SCALE, cube.c.b() / MODEL_SCALE, cube.c.c() / MODEL_SCALE);
   }

   public static void translateCubePivotBack(ModelCube cube, class_4587 matrices) {
      matrices.method_46416(-cube.c.a() / MODEL_SCALE, -cube.c.b() / MODEL_SCALE, -cube.c.c() / MODEL_SCALE);
   }

   public static void rotateCube(ModelCube cube, class_4587 matrices) {
      if (cube.d.c() != 0.0F) {
         matrices.method_22907(new Quaternionf().rotationZ(cube.d.c()));
      }

      if (cube.d.b() != 0.0F) {
         matrices.method_22907(new Quaternionf().rotationY(cube.d.b()));
      }

      if (cube.d.a() != 0.0F) {
         matrices.method_22907(new Quaternionf().rotationX(cube.d.a()));
      }
   }
}

package pulse;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10142;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import org.joml.Matrix4f;
import pulse.module.ClientModule;
import pulse.module.ModuleCategory;
import pulse.module.ModuleInfo;
import pulse.module.ModuleRegistry;
import pulse.settings.BooleanSetting;
import pulse.settings.ColorSetting;
import pulse.settings.SettingGroup;
import pulse.settings.SliderSetting;

@ModuleInfo(a = "China Hat", b = "Draws a cone hat above players.", c = ModuleCategory.VISUALS)
public class ChinaHat extends ClientModule {
   private static final int SEGMENTS = 90;

   private final SliderSetting height;
   private final SliderSetting radius;
   private final BooleanSetting followSneaking;
   private final SettingGroup colorGroup;
   private final BooleanSetting useClientColor;
   private final ColorSetting color;

   public ChinaHat() {
      this.height = new SliderSetting("Height", 0.3F, 0.1F, 0.6F, 0.05F);
      this.radius = new SliderSetting("Radius", 0.5F, 0.1F, 1.0F, 0.05F);
      this.followSneaking = new BooleanSetting("Follow Sneaking", true);
      this.colorGroup = new SettingGroup("Color");
      this.useClientColor = new BooleanSetting("Use Client Color", true);
      this.color = new ColorSetting("Custom Color", new Color(120, 80, 255)).a(() -> !this.useClientColor.a());
   }

   @EventHandler
   public void a(WorldRenderEvent event) {
      if (c.field_1724 == null || c.field_1687 == null || c.field_1773 == null) {
         return;
      }

      class_4587 matrices = event.a();
      class_243 camera = c.field_1773.method_19418().method_19326();
      matrices.method_22903();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableCull();
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);

      for (class_1657 player : c.field_1687.method_18456()) {
         if (player.method_5767()) {
            continue;
         }

         if (player == c.field_1724 && c.field_1690.method_31044().method_31034()) {
            continue;
         }

         this.renderHat(matrices, camera, player, event.b());
      }

      RenderSystem.depthMask(true);
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
      matrices.method_22909();
   }

   private void renderHat(class_4587 matrices, class_243 camera, class_1657 player, float tickDelta) {
      double x = class_3532.method_16436(tickDelta, player.field_6014, player.method_23317()) - camera.field_1352;
      double y = class_3532.method_16436(tickDelta, player.field_6036, player.method_23318()) - camera.field_1351 + player.method_17682() + 0.05D;
      double z = class_3532.method_16436(tickDelta, player.field_5969, player.method_23321()) - camera.field_1350;

      if (this.followSneaking.a() && player.method_5715()) {
         y -= 0.18D;
      }

      float radiusValue = this.radius.a();
      float heightValue = this.height.a();
      Color baseColor = this.n();
      Matrix4f matrix = matrices.method_23760().method_23761();

      RenderSystem.setShader(class_10142.field_53876);
      class_287 fill = class_289.method_1348().method_60827(class_5596.field_27379, class_290.field_1576);
      for (int segment = 0; segment < SEGMENTS; segment++) {
         float progress = (float)segment / SEGMENTS;
         float nextProgress = (float)(segment + 1) / SEGMENTS;
         double angle = progress * Math.PI * 2.0D;
         double nextAngle = nextProgress * Math.PI * 2.0D;
         Color segmentColor = this.a(baseColor, progress);

         vertex(fill, matrix, x, y + heightValue, z, segmentColor, 0.55F);
         vertex(fill, matrix, x + Math.cos(angle) * radiusValue, y, z + Math.sin(angle) * radiusValue, segmentColor, 0.28F);
         vertex(fill, matrix, x + Math.cos(nextAngle) * radiusValue, y, z + Math.sin(nextAngle) * radiusValue, this.a(baseColor, nextProgress), 0.28F);
      }
      class_286.method_43433(fill.method_60800());

      RenderSystem.lineWidth(2.0F);
      class_287 outline = class_289.method_1348().method_60827(class_5596.field_29344, class_290.field_1576);
      for (int segment = 0; segment < SEGMENTS; segment++) {
         float progress = (float)segment / SEGMENTS;
         float nextProgress = (float)(segment + 1) / SEGMENTS;
         double angle = progress * Math.PI * 2.0D;
         double nextAngle = nextProgress * Math.PI * 2.0D;
         Color segmentColor = this.a(baseColor, progress);

         vertex(outline, matrix, x + Math.cos(angle) * radiusValue, y, z + Math.sin(angle) * radiusValue, segmentColor, 0.95F);
         vertex(outline, matrix, x + Math.cos(nextAngle) * radiusValue, y, z + Math.sin(nextAngle) * radiusValue, this.a(baseColor, nextProgress), 0.95F);
      }
      class_286.method_43433(outline.method_60800());
      RenderSystem.lineWidth(1.0F);
   }

   private Color n() {
      return this.useClientColor.a() ? ModuleRegistry.CLIENT_COLOR.n() : this.color.a();
   }

   private Color a(Color color, float offset) {
      float[] hsb = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
      hsb[0] = (hsb[0] + (float)Math.sin(offset * Math.PI) * 0.08F) % 1.0F;
      if (hsb[0] < 0.0F) {
         hsb[0] += 1.0F;
      }
      return Color.getHSBColor(hsb[0], hsb[1], hsb[2]);
   }

   private static void vertex(class_287 buffer, Matrix4f matrix, double x, double y, double z, Color color, float alpha) {
      buffer.method_22918(matrix, (float)x, (float)y, (float)z)
         .method_22915(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, alpha);
   }
}

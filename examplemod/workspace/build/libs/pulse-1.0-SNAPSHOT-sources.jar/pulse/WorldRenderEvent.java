package pulse;

import net.minecraft.class_4587;

public class WorldRenderEvent extends PulseEvent {
   private final class_4587 matrices;
   private final float tickDelta;

   public WorldRenderEvent(class_4587 matrices, float tickDelta) {
      this.matrices = matrices;
      this.tickDelta = tickDelta;
   }

   public class_4587 matrices() {
      return this.matrices;
   }

   public float tickDelta() {
      return this.tickDelta;
   }

   public class_4587 a() {
      return this.matrices;
   }

   public float b() {
      return this.tickDelta;
   }
}

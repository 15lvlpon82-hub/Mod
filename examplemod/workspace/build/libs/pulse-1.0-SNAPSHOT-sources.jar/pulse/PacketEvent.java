package pulse;

import net.minecraft.class_2596;

public class PacketEvent extends CancellablePulseEvent {
   private final class_2596<?> packet;
   private final MessageDirection direction;

   public PacketEvent(class_2596<?> packet, MessageDirection direction) {
      this.packet = packet;
      this.direction = direction;
   }

   public class_2596<?> packet() {
      return this.packet;
   }

   public MessageDirection direction() {
      return this.direction;
   }

   public class_2596<?> d() {
      return this.packet;
   }

   public MessageDirection e() {
      return this.direction;
   }

   public enum MessageDirection {
      RECEIVE,
      SEND;

      public static final MessageDirection RECIEVE = RECEIVE;
   }
}

package ru.pulse.mixin;

import net.minecraft.class_2960;
import net.minecraft.class_742;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.CapeResolver;

@Mixin(class_742.class)
public abstract class AbstractClientPlayerEntityMixin {
   @Inject(method = "getSkinTextures", at = @At("RETURN"), cancellable = true)
   private void pulse$useCustomCapeTexture(CallbackInfoReturnable<class_8685> var1) {
      class_742 var2 = (class_742)(Object)this;
      if (CapeResolver.b(var2)) {
         class_2960 var3 = CapeResolver.a(var2);
         if (var3 != null) {
            class_8685 var4 = (class_8685)var1.getReturnValue();
            class_8685 var5 = new class_8685(var4.comp_1626(), var4.comp_1911(), var3, var4.comp_1628(), var4.comp_1629(), var4.comp_1630());
            var1.setReturnValue(var5);
         }
      }
   }
}

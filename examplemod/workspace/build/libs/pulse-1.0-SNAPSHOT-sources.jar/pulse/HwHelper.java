package pulse;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import pulse.module.ClientModule;
import pulse.module.ModuleCategory;
import pulse.module.ModuleInfo;
import pulse.settings.BooleanSetting;
import pulse.settings.SettingGroup;

@ModuleInfo(a = "HW Helper", b = "Shows helper timers for HolyWorld utility items.", c = ModuleCategory.UTILITIES)
public class HwHelper extends ClientModule {
    private static final long MESSAGE_DURATION_MS = 4_000L;
    private final BooleanSetting trackItems;
    private final BooleanSetting showStunTrap;
    private final BooleanSetting showExplosiveTrap;
    private final SettingGroup renderGroup;
    private final BooleanSetting renderNearbyTrapBox;
    private boolean stunTrapCooldownActive;
    private long stunTrapStartMs;
    private int lastStunTrapCount;
    private boolean explosiveTrapCooldownActive;
    private long explosiveTrapStartMs;
    private int lastExplosiveTrapCount;

    public HwHelper() {
        this.trackItems = new BooleanSetting("Track Items", true);
        this.showStunTrap = new BooleanSetting("Stun Trap", true);
        this.showExplosiveTrap = new BooleanSetting("Explosive Trap", true);
        this.renderGroup = new SettingGroup("Render");
        this.renderNearbyTrapBox = new BooleanSetting("Render Nearby Trap Box", true);
        this.lastStunTrapCount = 0;
        this.lastExplosiveTrapCount = 0;
    }

    @EventHandler
    public void a(WorldRenderEvent event) {
    }

    @EventHandler
    public void a(ClientTickEvent event) {
        if (c.field_1687 == null || c.field_1724 == null || !this.trackItems.k()) {
            return;
        }

        this.updateTrackedItem(class_1802.field_8662, this.showStunTrap.k(), true);
        this.updateTrackedItem(class_1802.field_8882, this.showExplosiveTrap.k(), false);
        this.showOverlayMessage();
    }

    private void updateTrackedItem(class_1792 item, boolean enabled, boolean stunTrap) {
        int currentCount = this.countItem(item);
        boolean coolingDown = c.field_1724.method_7357().method_7904(item.method_7854());
        int previousCount = stunTrap ? this.lastStunTrapCount : this.lastExplosiveTrapCount;
        if (enabled && coolingDown && currentCount < previousCount) {
            if (stunTrap) {
                this.stunTrapCooldownActive = true;
                this.stunTrapStartMs = System.currentTimeMillis();
            } else {
                this.explosiveTrapCooldownActive = true;
                this.explosiveTrapStartMs = System.currentTimeMillis();
            }
        }

        if (stunTrap) {
            this.lastStunTrapCount = currentCount;
        } else {
            this.lastExplosiveTrapCount = currentCount;
        }
    }

    private int countItem(class_1792 item) {
        int count = 0;
        for (int slot = 0; slot < c.field_1724.method_31548().method_5439(); slot++) {
            class_1799 stack = c.field_1724.method_31548().method_5438(slot);
            if (stack.method_7909() == item) {
                count += stack.method_7947();
            }
        }
        return count;
    }

    private void showOverlayMessage() {
        long now = System.currentTimeMillis();
        String stunMessage = this.getCooldownMessage("Stun Trap", now, this.stunTrapStartMs, this.stunTrapCooldownActive);
        if (stunMessage == null) {
            this.stunTrapCooldownActive = false;
        }

        String explosiveMessage = this.getCooldownMessage("Explosive Trap", now, this.explosiveTrapStartMs, this.explosiveTrapCooldownActive);
        if (explosiveMessage == null) {
            this.explosiveTrapCooldownActive = false;
        }

        String message;
        if (stunMessage != null && explosiveMessage != null) {
            message = stunMessage + " | " + explosiveMessage;
        } else {
            message = stunMessage != null ? stunMessage : explosiveMessage;
        }

        if (message != null) {
            c.field_1705.method_1758(class_2561.method_30163(message), false);
        }
    }

    private String getCooldownMessage(String name, long now, long startedAt, boolean active) {
        if (!active) {
            return null;
        }

        long elapsedMs = now - startedAt;
        if (elapsedMs >= MESSAGE_DURATION_MS) {
            return null;
        }

        double secondsLeft = (MESSAGE_DURATION_MS - elapsedMs) / 1000.0;
        return String.format("%ModuleCard cooldown: %.1fs", name, secondsLeft);
    }
}

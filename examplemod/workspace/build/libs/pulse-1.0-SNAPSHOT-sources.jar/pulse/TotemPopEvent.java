package pulse;

import net.minecraft.class_1309;
import net.minecraft.class_1799;

public class TotemPopEvent extends PulseEvent {
   private final class_1309 entity;
   private final class_1799 totemStack;

   public TotemPopEvent(class_1309 entity, class_1799 totemStack) {
      this.entity = entity;
      this.totemStack = totemStack;
   }

   public class_1309 entity() {
      return this.entity;
   }

   public class_1799 totemStack() {
      return this.totemStack;
   }

   public class_1309 a() {
      return this.entity;
   }

   public class_1799 b() {
      return this.totemStack;
   }
}

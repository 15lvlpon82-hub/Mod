package ru.pulse.mixin;


import pulse.module.ModuleRegistry;
import net.minecraft.class_10042;
import net.minecraft.class_10055;
import net.minecraft.class_1309;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_583;
import net.minecraft.class_640;
import net.minecraft.class_897;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.EventBusService;
import pulse.LivingEntityRenderEvent;

@Mixin(class_922.class)
public abstract class LivingEntityRendererMixin<T extends class_1309, S extends class_10042, M extends class_583<? super S>>
   extends class_897<T, S> {
   @Shadow
   protected M model;
   private static class_1309 capturedEntity;

   protected LivingEntityRendererMixin() {
      super(null);
   }

   @Inject(
      method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V",
      at = @At("HEAD")
   )
   private void captureEntity(T var1, S var2, float var3, CallbackInfo var4) {
      capturedEntity = var1;
   }

   @Inject(
      method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/entity/LivingEntityRenderer;shouldRenderFeatures(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;)Z"
      )
   )
   private void onRenderEntity(S var1, class_4587 var2, class_4597 var3, int var4, CallbackInfo var5) {
      LivingEntityRenderEvent var6 = new LivingEntityRenderEvent(capturedEntity, var1, var2, this.model, var3);
      EventBusService.EVENT_BUS.post(var6);
   }

   @Inject(
      method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
      at = @At("TAIL")
   )
   private void renderSelfNametag(S var1, class_4587 var2, class_4597 var3, int var4, CallbackInfo var5) {
      if (var1 instanceof class_10055 var6) {
         class_310 var7 = class_310.method_1551();
         if (var7.field_1724 != null && var6.field_53528 == var7.field_1724.method_5628()) {
            if (ModuleRegistry.SELF_NAMETAG.k() && !var7.field_1690.method_31044().method_31034()) {
               if (var6.field_53332 < 4096.0) {
                  var2.method_22903();
                  if (var6.field_53525 != null) {
                     super.method_3926(var1, var6.field_53525, var2, var3, var4);
                     var2.method_22904(0.0, 0.25875F, 0.0);
                  }

                  class_2561 var8 = getServerDisplayName(var7, var6.field_53529);
                  super.method_3926(var1, var8, var2, var3, var4);
                  var2.method_22909();
               }
            }
         }
      }
   }

   private static class_2561 getServerDisplayName(class_310 var0, String var1) {
      if (var0.method_1562() != null && var0.field_1724 != null) {
         class_640 var2 = var0.method_1562().method_2871(var0.field_1724.method_5667());
         if (var2 != null && var2.method_2971() != null) {
            return var2.method_2971();
         }
      }

      return class_2561.method_43470(var1);
   }
}

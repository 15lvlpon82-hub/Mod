package ru.pulse.mixin;


import pulse.module.ModuleRegistry;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_759;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.CustomHand;

@Mixin(class_759.class)
public abstract class HeldItemRendererMixin {
   @Shadow
   @Final
   private class_310 client;
   @Shadow
   private class_1799 offHand;

   @Shadow
   public abstract void renderItem(
      class_1309 var1, class_1799 var2, class_811 var3, boolean var4, class_4587 var5, class_4597 var6, int var7
   );

   @Shadow
   protected abstract void renderArmHoldingItem(class_4587 var1, class_4597 var2, int var3, float var4, float var5, class_1306 var6);

   @Shadow
   protected abstract void renderMapInOneHand(class_4587 var1, class_4597 var2, int var3, float var4, class_1306 var5, float var6, class_1799 var7);

   @Shadow
   protected abstract void renderMapInBothHands(class_4587 var1, class_4597 var2, int var3, float var4, float var5, float var6);

   @Shadow
   protected abstract void applyEatOrDrinkTransformation(class_4587 var1, float var2, class_1306 var3, class_1799 var4, class_1657 var5);

   @Shadow
   private void applySwingOffset(class_4587 var1, class_1306 var2, float var3) {
   }

   @Shadow
   private void applyEquipOffset(class_4587 var1, class_1306 var2, float var3) {
   }

   @Inject(method = "applySwingOffset", at = @At("HEAD"), cancellable = true)
   private void applySwingOffset_tr(class_4587 var1, class_1306 var2, float var3, CallbackInfo var4) {
      CustomHand customHand = ModuleRegistry.CUSTOM_HAND;
      if (customHand.k() && customHand.hasCustomSwingAnimation()) {
         int var10 = var2 == class_1306.field_6183 ? 1 : -1;
         float var11 = customHand.swingStrength.a() * 10.0F;
         float var12 = class_3532.method_15374(var3 * var3 * (float) Math.PI);
         var1.method_22907(class_7833.field_40716.rotationDegrees(var10 * (45.0F + var12 * (-var11 / 4.0F))));
         float var9 = class_3532.method_15374(class_3532.method_15355(var3) * (float) Math.PI);
         var1.method_22907(class_7833.field_40718.rotationDegrees(var10 * var9 * -(var11 / 4.0F)));
         var1.method_22907(class_7833.field_40714.rotationDegrees(var9 * -var11));
         var1.method_22907(class_7833.field_40716.rotationDegrees(var10 * -45.0F));
      } else {
         int var6 = var2 == class_1306.field_6183 ? 1 : -1;
         float var7 = class_3532.method_15374(var3 * var3 * (float) Math.PI);
         var1.method_22907(class_7833.field_40716.rotationDegrees(var6 * (45.0F + var7 * -20.0F)));
         float var8 = class_3532.method_15374(class_3532.method_15355(var3) * (float) Math.PI);
         var1.method_22907(class_7833.field_40718.rotationDegrees(var6 * var8 * -20.0F));
         var1.method_22907(class_7833.field_40714.rotationDegrees(var8 * -80.0F));
         var1.method_22907(class_7833.field_40716.rotationDegrees(var6 * -45.0F));
      }

      var4.cancel();
   }

   @Inject(method = "applyEquipOffset", at = @At("HEAD"), cancellable = true)
   private void applyEquipOffset_tr(class_4587 var1, class_1306 var2, float var3, CallbackInfo var4) {
      CustomHand customHand = ModuleRegistry.CUSTOM_HAND;
      int var6 = var2 == class_1306.field_6183 ? 1 : -1;
      if (customHand.k()) {
         boolean var11 = var2 == this.client.field_1690.method_42552().method_41753();
         float var7;
         float var8;
         float var9;
         float var10;
         if (var11) {
            var7 = customHand.mainHandScale.a();
            var8 = customHand.mainHandOffsetX.a();
            var9 = customHand.mainHandOffsetY.a();
            var10 = customHand.mainHandOffsetZ.a();
         } else {
            var7 = customHand.offHandScale.a();
            var8 = customHand.offHandOffsetX.a();
            var9 = customHand.offHandOffsetY.a();
            var10 = customHand.offHandOffsetZ.a();
         }

         boolean var12 = customHand.isNoAnimationMode();
         var1.method_46416(var6 * 0.56F, -0.52F + var3 * (var12 ? -0.6F : (customHand.hasCustomSwingAnimation() ? 0.0F : -0.6F)), -0.72F);
         var1.method_22905(var7, var7, var7);
         var1.method_46416(var8, var9, var10);
      } else {
         var1.method_46416(var6 * 0.56F, -0.52F + var3 * -0.6F, -0.72F);
      }

      var4.cancel();
   }

   @Inject(method = "renderFirstPersonItem", at = @At("HEAD"), cancellable = true)
   private void renderFirstPersonItem(
      class_742 var1,
      float var2,
      float var3,
      class_1268 var4,
      float var5,
      class_1799 var6,
      float var7,
      class_4587 var8,
      class_4597 var9,
      int var10,
      CallbackInfo var11
   ) {
      if (var1.method_31550()) {
         var11.cancel();
      } else {
         boolean var12 = var4 == class_1268.field_5808;
         class_1306 var13 = var12 ? var1.method_6068() : var1.method_6068().method_5928();
         CustomHand var14 = ModuleRegistry.CUSTOM_HAND;
         var8.method_22903();
         if (var6.method_7960()) {
            if (var12 && !var1.method_5767()) {
               this.renderArmHoldingItem(var8, var9, var10, var7, var5, var13);
            }
         } else if (var6.method_31574(class_1802.field_8204)) {
            if (var12 && this.offHand.method_7960()) {
               this.renderMapInBothHands(var8, var9, var10, var3, var7, var5);
            } else {
               this.renderMapInOneHand(var8, var9, var10, var7, var13, var5, var6);
            }
         } else if (var6.method_31574(class_1802.field_8399)) {
            boolean var15 = class_1764.method_7781(var6);
            boolean var20 = var13 == class_1306.field_6183;
            int var21 = var20 ? 1 : -1;
            if (var1.method_6115() && var1.method_6014() > 0 && var1.method_6058() == var4) {
               this.applyEquipOffset(var8, var13, var7);
               var8.method_46416(var21 * -0.4785682F, -0.094387F, 0.05731531F);
               var8.method_22907(class_7833.field_40714.rotationDegrees(-11.935F));
               var8.method_22907(class_7833.field_40716.rotationDegrees(var21 * 65.3F));
               var8.method_22907(class_7833.field_40718.rotationDegrees(var21 * -9.785F));
               float var26 = var6.method_7935(var1) - (var1.method_6014() - var2 + 1.0F);
               float var31 = var26 / class_1764.method_7775(var6, var1);
               if (var31 > 1.0F) {
                  var31 = 1.0F;
               }

               if (var31 > 0.1F) {
                  float var34 = class_3532.method_15374((var26 - 0.1F) * 1.3F);
                  float var19 = var31 - 0.1F;
                  float var22 = var34 * var19;
                  var8.method_46416(var22 * 0.0F, var22 * 0.004F, var22 * 0.0F);
               }

               var8.method_46416(var31 * 0.0F, var31 * 0.0F, var31 * 0.04F);
               var8.method_22905(1.0F, 1.0F, 1.0F + var31 * 0.2F);
               var8.method_22907(class_7833.field_40715.rotationDegrees(var21 * 45.0F));
            } else {
               float var16 = -0.4F * class_3532.method_15374(class_3532.method_15355(var5) * (float) Math.PI);
               float var17 = 0.2F * class_3532.method_15374(class_3532.method_15355(var5) * (float) (Math.PI * 2));
               float var18 = -0.2F * class_3532.method_15374(var5 * (float) Math.PI);
               var8.method_46416(var21 * var16, var17, var18);
               this.applyEquipOffset(var8, var13, var7);
               this.applySwingOffset(var8, var13, var5);
               if (var15 && var5 < 0.001F && var12) {
                  var8.method_46416(var21 * -0.641864F, 0.0F, 0.0F);
                  var8.method_22907(class_7833.field_40716.rotationDegrees(var21 * 10.0F));
               }
            }

            this.renderItem(var1, var6, var20 ? class_811.field_4322 : class_811.field_4321, !var20, var8, var9, var10);
         } else {
            boolean var25 = var13 == class_1306.field_6183;
            if (var1.method_6115() && var1.method_6014() > 0 && var1.method_6058() == var4) {
               int var40 = var25 ? 1 : -1;
               switch (var6.method_7976()) {
                  case field_8952:
                     this.applyEquipOffset(var8, var13, var7);
                     break;
                  case field_8950:
                  case field_8946:
                     this.applyEatOrDrinkTransformation(var8, var2, var13, var6, var1);
                     this.applyEquipOffset(var8, var13, var7);
                     break;
                  case field_8949:
                     this.applyEquipOffset(var8, var13, var7);
                     break;
                  case field_8953:
                     this.applyEquipOffset(var8, var13, var7);
                     var8.method_46416(var40 * -0.2785682F, 0.18344387F, 0.15731531F);
                     var8.method_22907(class_7833.field_40714.rotationDegrees(-13.935F));
                     var8.method_22907(class_7833.field_40716.rotationDegrees(var40 * 35.3F));
                     var8.method_22907(class_7833.field_40718.rotationDegrees(var40 * -9.785F));
                     float var43 = var6.method_7935(var1) - (var1.method_6014() - var2 + 1.0F);
                     float var29 = var43 / 20.0F;
                     var29 = (var29 * var29 + var29 * 2.0F) / 3.0F;
                     if (var29 > 1.0F) {
                        var29 = 1.0F;
                     }

                     if (var29 > 0.1F) {
                        float var33 = class_3532.method_15374((var43 - 0.1F) * 1.3F);
                        float var36 = var29 - 0.1F;
                        float var38 = var33 * var36;
                        var8.method_46416(var38 * 0.0F, var38 * 0.004F, var38 * 0.0F);
                     }

                     var8.method_46416(var29 * 0.0F, var29 * 0.0F, var29 * 0.04F);
                     var8.method_22905(1.0F, 1.0F, 1.0F + var29 * 0.2F);
                     var8.method_22907(class_7833.field_40715.rotationDegrees(var40 * 45.0F));
                     break;
                  case field_8951:
                     this.applyEquipOffset(var8, var13, var7);
                     var8.method_46416(var40 * -0.5F, 0.7F, 0.1F);
                     var8.method_22907(class_7833.field_40714.rotationDegrees(-55.0F));
                     var8.method_22907(class_7833.field_40716.rotationDegrees(var40 * 35.3F));
                     var8.method_22907(class_7833.field_40718.rotationDegrees(var40 * -9.785F));
                     float var42 = var6.method_7935(var1) - (var1.method_6014() - var2 + 1.0F);
                     float var28 = var42 / 10.0F;
                     if (var28 > 1.0F) {
                        var28 = 1.0F;
                     }

                     if (var28 > 0.1F) {
                        float var32 = class_3532.method_15374((var42 - 0.1F) * 1.3F);
                        float var35 = var28 - 0.1F;
                        float var37 = var32 * var35;
                        var8.method_46416(var37 * 0.0F, var37 * 0.004F, var37 * 0.0F);
                     }

                     var8.method_46416(0.0F, 0.0F, var28 * 0.2F);
                     var8.method_22905(1.0F, 1.0F, 1.0F + var28 * 0.2F);
                     var8.method_22907(class_7833.field_40715.rotationDegrees(var40 * 45.0F));
                  case field_42717:
               }
            } else if (var1.method_6123()) {
               this.applyEquipOffset(var8, var13, var7);
               int var39 = var25 ? 1 : -1;
               var8.method_46416(var39 * -0.4F, 0.8F, 0.3F);
               var8.method_22907(class_7833.field_40716.rotationDegrees(var39 * 65.0F));
               var8.method_22907(class_7833.field_40718.rotationDegrees(var39 * -85.0F));
            } else {
               float var44 = -0.4F * class_3532.method_15374(class_3532.method_15355(var5) * (float) Math.PI);
               float var41 = 0.2F * class_3532.method_15374(class_3532.method_15355(var5) * (float) (Math.PI * 2));
               float var27 = -0.2F * class_3532.method_15374(var5 * (float) Math.PI);
               int var23 = var25 ? 1 : -1;
               if (var14 == null || !var14.k() || var14.isNoAnimationMode()) {
                  var8.method_46416(var23 * var44, var41, var27);
               }

               this.applyEquipOffset(var8, var13, var7);
               boolean var24 = var4 == class_1268.field_5808;
               if (var14 == null || !var14.k() || !var24) {
                  this.applySwingOffset(var8, var13, var5);
               } else if (var14.isNoAnimationMode()) {
                  this.applySwingOffset(var8, var13, var5);
               } else if (var14.hasCustomSwingAnimation()) {
                  var14.applyCustomSwing(var8, var5, () -> this.applySwingOffset(var8, var13, var5), var13 == class_1306.field_6182);
               } else {
                  this.applySwingOffset(var8, var13, var5);
               }
            }

            this.renderItem(var1, var6, var25 ? class_811.field_4322 : class_811.field_4321, !var25, var8, var9, var10);
         }

         var8.method_22909();
         var11.cancel();
      }
   }
}

package ru.pulse.mixin;


import pulse.module.ModuleRegistry;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1812;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_746;
import net.minecraft.class_9848;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.EventBusService;
import pulse.ItemOverlayRenderEvent;
import pulse.AutoReissue;
import pulse.Cooldowns;
import pulse.HealingHelper;
import pulse.ItemHighlighter;
import pulse.CooldownInfo;

@Mixin(class_332.class)
public abstract class DrawContextMixin {
   @Shadow
   @Final
   private class_4587 matrices;
   @Shadow
   @Final
   private class_310 client;

   @Shadow
   public abstract int drawText(class_327 var1, @Nullable String var2, int var3, int var4, int var5, boolean var6);

   @Shadow
   public abstract void fill(class_1921 var1, int var2, int var3, int var4, int var5, int var6);

   @Shadow
   public abstract void fill(class_1921 var1, int var2, int var3, int var4, int var5, int var6, int var7);

   @Inject(
      method = "drawItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/world/World;Lnet/minecraft/item/ItemStack;IIII)V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/math/MatrixStack;push()V", shift = Shift.AFTER)
   )
   private void renderItemHighlight(class_1309 var1, class_1937 var2, class_1799 var3, int var4, int var5, int var6, int var7, CallbackInfo var8) {
      ItemHighlighter var9 = ModuleRegistry.ITEM_HIGHLIGHTER;
      if (var9 != null && var9.k() && var9.a(var3)) {
         Color var10 = var9.a(var3.method_7909());
         int var11 = var9.n();
         int var12 = new Color(var10.getRed(), var10.getGreen(), var10.getBlue(), var11).getRGB();
         this.matrices.method_22903();
         this.matrices.method_46416(0.0F, 0.0F, 100.0F);
         this.fill(class_1921.method_51785(), var4, var5, var4 + 16, var5 + 16, var12);
         this.matrices.method_22909();
      }
   }

   @Inject(
      method = "drawStackOverlay(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/item/ItemStack;IILjava/lang/String;)V",
      at = @At("HEAD"),
      cancellable = true
   )
   private void onDrawStackOverlay(class_327 var1, class_1799 var2, int var3, int var4, @Nullable String var5, CallbackInfo var6) {
      if (!var2.method_7960()) {
         this.matrices.method_22903();
         if (var2.method_7947() != 1 || var5 != null) {
            String var7 = var5 == null ? String.valueOf(var2.method_7947()) : var5;
            this.matrices.method_46416(0.0F, 0.0F, 200.0F);
            this.drawText(var1, var7, var3 + 19 - 2 - var1.method_1727(var7), var4 + 6 + 3, -1, true);
         }

         if (var2.method_31578()) {
            int var26 = var2.method_31579();
            int var8 = var2.method_31580();
            int var9 = var3 + 2;
            int var10 = var4 + 13;
            this.fill(class_1921.method_51784(), var9, var10, var9 + 13, var10 + 2, 200, -16777216);
            this.fill(class_1921.method_51784(), var9, var10, var9 + var26, var10 + 1, 200, class_9848.method_61334(var8));
         }

         class_746 var27 = class_310.method_1551().field_1724;
         class_1792 var28 = var2.method_7909();
         float var29 = 0.0F;
         if (var27 != null) {
            CooldownInfo.ItemCooldownSnapshot var30 = CooldownInfo.a(var27.method_7357(), var28);
            var29 = var30.c();
         }

         Cooldowns var31 = ModuleRegistry.COOLDOWNS;
         boolean var11 = Cooldowns.a(var2);
         if (var31 != null && var31.k() && Cooldowns.a(var2)) {
            float var12 = var31.a(var2.method_7909());
            if (var12 > var29) {
               var29 = var12;
            }
         }

         if (var29 > 0.0F) {
            boolean var32 = true;
            if (var2.method_7909() instanceof class_1812) {
               var32 = var11;
            }

            if (var32) {
               RenderSystem.disableDepthTest();
               RenderSystem.enableBlend();
               RenderSystem.defaultBlendFunc();
               int var13 = class_3532.method_15386(16.0F * var29);
               int var14 = var4 + class_3532.method_15375(16.0F * (1.0F - var29));
               this.fill(class_1921.method_51784(), var3, var14, var3 + 16, var14 + var13, 200, new Color(255, 255, 255, 127).getRGB());
               RenderSystem.enableDepthTest();
            }
         }

         if (var2.method_7909() == class_1802.field_8557) {
            AutoReissue var33 = ModuleRegistry.AUTO_REISSUE;
            if (var33 != null && var33.k()) {
               class_310 var35 = class_310.method_1551();
               if (var35.field_1755 != null && var35.field_1724.field_7512 != null) {
                  String var38 = "";

                  try {
                     var38 = var35.field_1755.method_25440().getString();
                  } catch (Exception var25) {
                  }

                  if (var33.overlayActive) {
                     long var15 = var33.timer.a(0L) ? var33.durationMs : 0L;

                     for (int var17 = 1; var17 <= var33.durationMs / 1000 + 1; var17++) {
                        if (!var33.timer.a(var17 * 1000)) {
                           var15 = (var17 - 1) * 1000;
                           break;
                        }
                     }

                     int var41 = Math.max(0, (var33.durationMs - (int)var15) / 1000);
                     float var18 = Math.max(0.0F, 1.0F - (float)var15 / var33.durationMs);
                     if (var41 > 0) {
                        byte var19 = 16;
                        int var20 = class_3532.method_15386(var19 * var18);
                        int var21 = var4 + (var19 - var20);
                        this.fill(class_1921.method_51784(), var3, var21, var3 + 16, var21 + var20, 200, new Color(255, 255, 255, 127).getRGB());
                        String var22 = String.valueOf(var41);
                        int var23 = var3 + 8 - var1.method_1727(var22) / 2;
                        int var24 = var4 + 8 - 9 / 2;
                        this.matrices.method_22903();
                        this.matrices.method_46416(0.0F, 0.0F, 300.0F);
                        this.drawText(var1, var22, var23, var24, -1, true);
                        this.matrices.method_22909();
                     }
                  }
               }
            }
         }

         HealingHelper var34 = ModuleRegistry.HEALING_HELPER;
         if (var34 != null && var34.k() && var34.a(var2)) {
            List<class_1792> var36 = var34.n();
            int var39 = var36.stream().mapToInt(var34::a).max().orElse(1);
            int var40 = var34.a(var2.method_7909());
            float var16 = class_3532.method_15363((float)var40 / var39, 0.0F, 1.0F);
            int var42 = (int)(255.0F * (1.0F - var16));
            int var43 = (int)(255.0F * var16);
            int var44 = (int)((Math.sin(System.currentTimeMillis() / 100.0) * 0.5 + 0.5) * 100.0) + 50;
            int var45 = new Color(var42, var43, 0, var44).getRGB();
            this.matrices.method_22903();
            this.matrices.method_46416(0.0F, 0.0F, 200.0F);
            this.fill(class_1921.method_51785(), var3, var4, var3 + 16, var4 + 16, var45);
            this.matrices.method_22909();
         }

         class_332 var37 = (class_332)(Object)this;
         EventBusService.EVENT_BUS.post(new ItemOverlayRenderEvent(var2, var3, var4));
         this.matrices.method_22909();
         var6.cancel();
      }
   }
}

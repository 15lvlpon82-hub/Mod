package pulse;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_5498;
import org.lwjgl.glfw.GLFW;
import pulse.module.ClientModule;
import pulse.module.ModuleCategory;
import pulse.module.ModuleInfo;
import pulse.settings.KeySetting;
import pulse.settings.ModeSetting;

@ModuleInfo(a = "Free Look", b = "Lets the camera rotate independently from the player.", c = ModuleCategory.UTILITIES)
public class FreeLook extends ClientModule {
    public final ModeSetting mode;
    public final KeySetting key;
    public static boolean active;
    public static float cameraYaw;
    public static float cameraPitch;
    private class_5498 previousPerspective;
    private boolean activatedByThisModule;
    private boolean previousKeyPressed;

    public FreeLook() {
        this.mode = new ModeSetting("Mode", new String[]{"Hold", "Toggle"}, 0);
        this.key = new KeySetting("Key", GLFW.GLFW_KEY_LEFT_ALT);
        this.previousPerspective = class_5498.field_26664;
        this.activatedByThisModule = false;
        this.previousKeyPressed = false;
    }

    @EventHandler
    public void a(ClientTickEvent event) {
        if (c == null || c.field_1724 == null || c.field_1687 == null || c.method_22683() == null || c.field_1755 != null) {
            this.resetIfNeeded();
            return;
        }

        int keyCode = this.key.a();
        if (keyCode <= GLFW.GLFW_KEY_UNKNOWN) {
            this.resetIfNeeded();
            return;
        }

        boolean pressed = GLFW.glfwGetKey(c.method_22683().method_4490(), keyCode) == GLFW.GLFW_PRESS;
        boolean toggleMode = this.mode.k() != 0;
        if (toggleMode) {
            if (pressed && !this.previousKeyPressed) {
                if (active) {
                    this.disableFreeLook();
                    this.activatedByThisModule = false;
                } else {
                    this.enableFreeLook();
                    this.activatedByThisModule = true;
                }
            }
        } else if (pressed && !active) {
            this.enableFreeLook();
            this.activatedByThisModule = true;
        } else if (!pressed && active && this.activatedByThisModule) {
            this.disableFreeLook();
            this.activatedByThisModule = false;
        }

        this.previousKeyPressed = pressed;
    }

    private void enableFreeLook() {
        if (c == null || c.field_1724 == null || c.field_1690 == null) {
            return;
        }

        this.previousPerspective = c.field_1690.method_31044();
        cameraYaw = c.field_1724.method_5705(1.0F);
        cameraPitch = c.field_1724.method_5695(1.0F);
        c.field_1690.method_31043(class_5498.field_26665);
        active = true;
    }

    private void disableFreeLook() {
        if (c != null && c.field_1690 != null) {
            c.field_1690.method_31043(this.previousPerspective);
        }

        active = false;
    }

    private void resetIfNeeded() {
        if (active && this.activatedByThisModule) {
            this.disableFreeLook();
        }

        this.activatedByThisModule = false;
        this.previousKeyPressed = false;
    }

    @Override
    public void f() {
        if (active) {
            this.disableFreeLook();
        }

        this.activatedByThisModule = false;
        this.previousKeyPressed = false;
        super.f();
    }
}

package pulse;

import net.minecraft.class_1304;
import net.minecraft.class_1664;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_742;
import ru.pulse.Pulse;

public final class CapeResolver {
   private CapeResolver() {
   }

   public static class_2960 a(class_742 player) {
      Integer capeId = resolveCapeId(player);
      return capeId == null ? null : CapeTextureCache.getInstance().getCapeTexture(capeId);
   }

   public static boolean b(class_742 player) {
      if (player == null || a(player) == null) {
         return false;
      }

      if (player.method_5767() || !player.method_7348(class_1664.field_7559)) {
         return false;
      }

      return player.method_6118(class_1304.field_6174).method_7909() != class_1802.field_8833;
   }

   private static Integer resolveCapeId(class_742 player) {
      if (player == null) {
         return null;
      }

      class_310 client = class_310.method_1551();
      if (client.field_1724 != null && client.field_1724.method_5628() == player.method_5628()) {
         UserInfo userInfo = Pulse.getUserInfo();
         return userInfo == null ? null : userInfo.b();
      }

      String playerName = player.method_7334() == null ? null : player.method_7334().getName();
      return PlayerListCache.c().b(playerName);
   }
}

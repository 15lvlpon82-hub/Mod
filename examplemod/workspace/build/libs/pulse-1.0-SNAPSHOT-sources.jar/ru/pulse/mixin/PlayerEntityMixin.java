package ru.pulse.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.EventBusService;
import pulse.CriticalHitEvent;

@Mixin(class_1657.class)
public class PlayerEntityMixin {
   @Inject(
      method = "attack",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;addCritParticles(Lnet/minecraft/entity/Entity;)V")
   )
   private void onCriticalHit(class_1297 var1, CallbackInfo var2) {
      EventBusService.EVENT_BUS.post(new CriticalHitEvent(var1));
   }
}

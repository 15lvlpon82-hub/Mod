package pulse;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675.class_307;

public final class ClickGuiKeyBinding {
   public static class_304 OPEN_KEY;

   private ClickGuiKeyBinding() {
   }

   public static void register() {
      OPEN_KEY = KeyBindingHelper.registerKeyBinding(new class_304("Open Click GUI", class_307.field_1668, 344, "Pulse"));
   }
}

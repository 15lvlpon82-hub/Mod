package pulse;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10142;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4587;
import net.minecraft.class_9278;
import net.minecraft.class_9334;
import org.joml.Matrix4f;
import pulse.module.ClientModule;
import pulse.module.ModuleCategory;
import pulse.module.ModuleInfo;
import pulse.module.ModuleRegistry;
import pulse.settings.BooleanSetting;
import pulse.settings.ColorSetting;
import pulse.settings.SettingGroup;
import pulse.settings.SliderSetting;

@ModuleInfo(a = "Predictions", b = "Predicts projectile trajectories.", c = ModuleCategory.UTILITIES)
public class Predictions extends ClientModule {
   private static final int MAX_STEPS = 220;
   private static final int MARKER_SEGMENTS = 48;

   private final SettingGroup projectileGroup;
   private final BooleanSetting arrows;
   private final BooleanSetting enderPearls;
   private final BooleanSetting tridents;
   private final BooleanSetting potions;
   private final SettingGroup lineGroup;
   private final SliderSetting lineWidth;
   private final BooleanSetting useClientColor;
   private final ColorSetting lineColor;
   private final BooleanSetting gradient;
   private final ColorSetting gradientColor;
   private final BooleanSetting fadeOut;
   private final SliderSetting fadeStart;
   private final SettingGroup markerGroup;
   private final BooleanSetting impactMarker;
   private final SliderSetting markerSize;
   private final BooleanSetting markerPulse;
   private final SliderSetting markerPulseSpeed;
   private final ColorSetting hitColor;

   private final List<class_243> path = new ArrayList<>();
   private class_243 impactPoint;
   private boolean hitEntity;

   public Predictions() {
      this.projectileGroup = new SettingGroup("Projectiles");
      this.arrows = new BooleanSetting("Arrows", true);
      this.enderPearls = new BooleanSetting("Ender Pearls", true);
      this.tridents = new BooleanSetting("Tridents", true);
      this.potions = new BooleanSetting("Potions", true);

      this.lineGroup = new SettingGroup("Line");
      this.lineWidth = new SliderSetting("Line Width", 2.0F, 1.0F, 6.0F, 0.25F);
      this.useClientColor = new BooleanSetting("Use Client Color", true);
      this.lineColor = new ColorSetting("Line Color", new Color(120, 80, 255)).a(() -> !this.useClientColor.a());
      this.gradient = new BooleanSetting("Gradient", true);
      this.gradientColor = new ColorSetting("Gradient Color", new Color(80, 180, 255)).a(this.gradient::a);
      this.fadeOut = new BooleanSetting("Fade Out", true);
      this.fadeStart = new SliderSetting("Fade Start", 0.65F, 0.1F, 0.95F, 0.05F).a(this.fadeOut::a);

      this.markerGroup = new SettingGroup("Impact Marker");
      this.impactMarker = new BooleanSetting("Impact Marker", true);
      this.markerSize = new SliderSetting("Marker Size", 0.35F, 0.1F, 1.2F, 0.05F).a(this.impactMarker::a);
      this.markerPulse = new BooleanSetting("Pulse", true).a(this.impactMarker::a);
      this.markerPulseSpeed = new SliderSetting("Pulse Speed", 1.0F, 0.2F, 3.0F, 0.1F).a(() -> this.impactMarker.a() && this.markerPulse.a());
      this.hitColor = new ColorSetting("Hit Color", new Color(255, 85, 110)).a(this.impactMarker::a);
   }

   @EventHandler
   public void a(WorldRenderEvent event) {
      if (c.field_1724 == null || c.field_1687 == null || c.field_1773 == null) {
         this.clearPrediction();
         return;
      }

      class_1799 stack = this.currentProjectileStack();
      ProjectileType type = ProjectileType.from(stack);
      if (type == null || !this.isEnabled(type) || !this.isReady(stack, type)) {
         this.clearPrediction();
         return;
      }

      this.simulate(event.b(), stack, type);
      if (this.path.size() > 1) {
         this.render(event);
      }
   }

   private class_1799 currentProjectileStack() {
      class_1799 mainHand = c.field_1724.method_6047();
      if (ProjectileType.from(mainHand) != null) {
         return mainHand;
      }

      class_1799 offHand = c.field_1724.method_6079();
      return ProjectileType.from(offHand) != null ? offHand : class_1799.field_8037;
   }

   private boolean isEnabled(ProjectileType type) {
      return switch (type) {
         case ARROW -> this.arrows.a();
         case ENDER_PEARL -> this.enderPearls.a();
         case TRIDENT -> this.tridents.a();
         case POTION -> this.potions.a();
      };
   }

   private boolean isReady(class_1799 stack, ProjectileType type) {
      class_1792 item = stack.method_7909();
      if (item == class_1802.field_8102 || item == class_1802.field_8547) {
         return c.field_1724.method_6115() && c.field_1724.method_6014() > 0;
      }

      if (item == class_1802.field_8399) {
         class_9278 chargedProjectiles = stack.method_57824(class_9334.field_49649);
         return chargedProjectiles != null && !chargedProjectiles.method_57442();
      }

      return type == ProjectileType.ENDER_PEARL || type == ProjectileType.POTION;
   }

   private void simulate(float tickDelta, class_1799 stack, ProjectileType type) {
      this.path.clear();
      this.impactPoint = null;
      this.hitEntity = false;

      class_243 position = c.field_1724.method_5836(tickDelta);
      class_243 velocity = this.initialVelocity(stack, type);
      this.path.add(position);

      for (int step = 0; step < MAX_STEPS; step++) {
         class_243 nextPosition = position.method_1019(velocity);
         class_3965 blockHit = c.field_1687.method_17742(
            new class_3959(position, nextPosition, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, c.field_1724)
         );

         boolean collided = false;
         if (blockHit.method_17783() != class_239.class_240.field_1333) {
            nextPosition = blockHit.method_17784();
            collided = true;
         }

         class_3966 entityHit = this.findEntityHit(position, nextPosition);
         if (entityHit != null) {
            nextPosition = entityHit.method_17784();
            this.hitEntity = true;
            collided = true;
         }

         this.path.add(nextPosition);
         if (collided) {
            this.impactPoint = nextPosition;
            return;
         }

         if (nextPosition.field_1351 < c.field_1687.method_31607() - 16.0D) {
            return;
         }

         position = nextPosition;
         velocity = velocity.method_1021(type.drag).method_1023(0.0D, type.gravity, 0.0D);
      }
   }

   private class_243 initialVelocity(class_1799 stack, ProjectileType type) {
      class_243 direction = this.lookDirection();
      double speed = type.baseSpeed;
      class_1792 item = stack.method_7909();

      if (item == class_1802.field_8102) {
         int usedTicks = stack.method_7935(c.field_1724) - c.field_1724.method_6014();
         float charge = Math.min(1.0F, Math.max(0.05F, (usedTicks / 20.0F * usedTicks / 20.0F + usedTicks / 20.0F * 2.0F) / 3.0F));
         speed = 3.0D * charge;
      } else if (item == class_1802.field_8547) {
         int usedTicks = stack.method_7935(c.field_1724) - c.field_1724.method_6014();
         float charge = Math.min(1.0F, Math.max(0.1F, usedTicks / 10.0F));
         speed = 2.5D * charge;
      }

      return direction.method_1021(speed).method_1019(c.field_1724.method_18798().method_1021(0.35D));
   }

   private class_243 lookDirection() {
      float yaw = c.field_1724.method_36454();
      float pitch = c.field_1724.method_36455();
      float pitchCos = (float)Math.cos(-pitch * (Math.PI / 180.0D));
      float pitchSin = (float)Math.sin(-pitch * (Math.PI / 180.0D));
      float yawCos = (float)Math.cos(-yaw * (Math.PI / 180.0D) - Math.PI);
      float yawSin = (float)Math.sin(-yaw * (Math.PI / 180.0D) - Math.PI);
      return new class_243(yawSin * pitchCos, pitchSin, yawCos * pitchCos).method_1029();
   }

   private class_3966 findEntityHit(class_243 from, class_243 to) {
      class_1297 closestEntity = null;
      class_243 closestHit = null;
      double closestDistance = Double.MAX_VALUE;
      class_238 searchBox = new class_238(from, to).method_1014(1.0D);

      for (class_1297 entity : c.field_1687.method_8335(c.field_1724, searchBox)) {
         if (entity == c.field_1724 || entity.method_7325() || !entity.method_5805() || !(entity instanceof class_1309)) {
            continue;
         }

         Optional<class_243> hit = entity.method_5829().method_1014(0.3D).method_992(from, to);
         if (hit.isPresent()) {
            double distance = from.method_1025(hit.get());
            if (distance < closestDistance) {
               closestDistance = distance;
               closestEntity = entity;
               closestHit = hit.get();
            }
         }
      }

      return closestEntity == null ? null : new class_3966(closestEntity, closestHit);
   }

   private void render(WorldRenderEvent event) {
      class_4587 matrices = event.a();
      class_243 camera = c.field_1773.method_19418().method_19326();

      matrices.method_22903();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableCull();
      RenderSystem.disableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.setShader(class_10142.field_53876);

      Matrix4f matrix = matrices.method_23760().method_23761();
      RenderSystem.lineWidth(this.lineWidth.a());
      class_287 line = class_289.method_1348().method_60827(class_5596.field_27378, class_290.field_1576);
      for (int index = 0; index < this.path.size(); index++) {
         class_243 point = this.path.get(index);
         float progress = this.path.size() <= 1 ? 0.0F : (float)index / (float)(this.path.size() - 1);
         Color color = this.pathColor(progress);
         float alpha = this.alpha(progress);
         vertex(line, matrix, point.method_1020(camera), color, alpha);
      }
      class_286.method_43433(line.method_60800());
      RenderSystem.lineWidth(1.0F);

      if (this.impactMarker.a() && this.impactPoint != null) {
         this.renderImpactMarker(matrix, camera);
      }

      RenderSystem.depthMask(true);
      RenderSystem.enableDepthTest();
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
      matrices.method_22909();
   }

   private void renderImpactMarker(Matrix4f matrix, class_243 camera) {
      Color color = this.hitEntity ? this.hitColor.a() : this.pathColor(1.0F);
      float pulse = this.markerPulse.a()
         ? 1.0F + 0.18F * (float)Math.sin(System.currentTimeMillis() * 0.006D * this.markerPulseSpeed.a())
         : 1.0F;
      float size = this.markerSize.a() * pulse;
      class_243 center = this.impactPoint.method_1020(camera);

      RenderSystem.lineWidth(2.0F);
      class_287 ring = class_289.method_1348().method_60827(class_5596.field_29344, class_290.field_1576);
      for (int segment = 0; segment < MARKER_SEGMENTS; segment++) {
         double angle = Math.PI * 2.0D * segment / MARKER_SEGMENTS;
         double nextAngle = Math.PI * 2.0D * (segment + 1) / MARKER_SEGMENTS;
         vertex(ring, matrix, center.method_1031(Math.cos(angle) * size, 0.01D, Math.sin(angle) * size), color, 0.9F);
         vertex(ring, matrix, center.method_1031(Math.cos(nextAngle) * size, 0.01D, Math.sin(nextAngle) * size), color, 0.9F);
      }
      class_286.method_43433(ring.method_60800());
      RenderSystem.lineWidth(1.0F);
   }

   private Color pathColor(float progress) {
      Color start = this.useClientColor.a() ? ModuleRegistry.CLIENT_COLOR.n() : this.lineColor.a();
      if (!this.gradient.a()) {
         return start;
      }

      Color end = this.gradientColor.a();
      return new Color(
         lerp(start.getRed(), end.getRed(), progress),
         lerp(start.getGreen(), end.getGreen(), progress),
         lerp(start.getBlue(), end.getBlue(), progress)
      );
   }

   private float alpha(float progress) {
      if (!this.fadeOut.a() || progress <= this.fadeStart.a()) {
         return 1.0F;
      }

      float range = 1.0F - this.fadeStart.a();
      return Math.max(0.0F, 1.0F - (progress - this.fadeStart.a()) / range);
   }

   private void clearPrediction() {
      this.path.clear();
      this.impactPoint = null;
      this.hitEntity = false;
   }

   private static int lerp(int start, int end, float progress) {
      return Math.round(start + (end - start) * Math.max(0.0F, Math.min(1.0F, progress)));
   }

   private static void vertex(class_287 buffer, Matrix4f matrix, class_243 point, Color color, float alpha) {
      buffer.method_22918(matrix, (float)point.field_1352, (float)point.field_1351, (float)point.field_1350)
         .method_22915(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, alpha);
   }

   private enum ProjectileType {
      ENDER_PEARL(1.5D, 0.99D, 0.03D),
      TRIDENT(2.5D, 0.99D, 0.05D),
      ARROW(3.0D, 0.99D, 0.05D),
      POTION(0.5D, 0.99D, 0.05D);

      private final double baseSpeed;
      private final double drag;
      private final double gravity;

      ProjectileType(double baseSpeed, double drag, double gravity) {
         this.baseSpeed = baseSpeed;
         this.drag = drag;
         this.gravity = gravity;
      }

      private static ProjectileType from(class_1799 stack) {
         if (stack == null || stack.method_7960()) {
            return null;
         }

         class_1792 item = stack.method_7909();
         if (item == class_1802.field_8634) {
            return ENDER_PEARL;
         }
         if (item == class_1802.field_8547) {
            return TRIDENT;
         }
         if (item == class_1802.field_8102 || item == class_1802.field_8399) {
            return ARROW;
         }
         return item == class_1802.field_8436 || item == class_1802.field_8150 ? POTION : null;
      }
   }
}

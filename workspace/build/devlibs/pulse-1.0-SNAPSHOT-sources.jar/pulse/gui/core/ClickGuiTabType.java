package pulse;

public enum ClickGuiTabType {
   MODULES("modules", "\ue916"),
   MARKERS("markers", "\ue915"),
   FRIENDS("friends", "\ue90d"),
   EVENTS("events", "\ue90a"),
   CONFIGS("configs", "\ue905");

   private final String id;
   private final String icon;

   ClickGuiTabType(String id, String icon) {
      this.id = id;
      this.icon = icon;
   }

   public String a() {
      return this.id;
   }

   public String b() {
      return this.icon;
   }
}

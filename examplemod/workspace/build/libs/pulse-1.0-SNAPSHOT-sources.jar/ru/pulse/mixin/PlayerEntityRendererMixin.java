package ru.pulse.mixin;


import pulse.module.ModuleRegistry;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_640;
import net.minecraft.class_742;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1007.class)
public abstract class PlayerEntityRendererMixin extends class_897<class_742, class_10055> {
   protected PlayerEntityRendererMixin() {
      super(null);
   }

   @Inject(
      method = "renderLabelIfPresent(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;Lnet/minecraft/text/Text;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
      at = @At("HEAD")
   )
   private void onRenderLabel(class_10055 var1, class_2561 var2, class_4587 var3, class_4597 var4, int var5, CallbackInfo var6) {
      class_310 var7 = class_310.method_1551();
      if (var7.field_1724 != null && var1.field_53528 == var7.field_1724.method_5628()) {
         if (ModuleRegistry.SELF_NAMETAG.k() && !var7.field_1690.method_31044().method_31034()) {
            if (var1.field_53332 < 4096.0) {
               var3.method_22903();
               if (var1.field_53525 != null) {
                  super.method_3926(var1, var1.field_53525, var3, var4, var5);
                  var3.method_22904(0.0, 0.25875F, 0.0);
               }

               Object var8;
               if (var7.method_1562() != null) {
                  class_640 var9 = var7.method_1562().method_2871(var7.field_1724.method_5667());
                  if (var9 != null && var9.method_2971() != null) {
                     var8 = var9.method_2971();
                  } else {
                     var8 = class_2561.method_43470(var1.field_53529);
                  }
               } else {
                  var8 = class_2561.method_43470(var1.field_53529);
               }

               super.method_3926(var1, (class_2561)var8, var3, var4, var5);
               var3.method_22909();
            }
         }
      }
   }
}

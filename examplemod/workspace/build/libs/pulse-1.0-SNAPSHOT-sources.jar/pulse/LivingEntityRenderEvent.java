package pulse;

import net.minecraft.class_10042;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_583;

public class LivingEntityRenderEvent extends PulseEvent {
   private final class_1309 entity;
   private final class_10042 renderState;
   private final class_4587 matrices;
   private final class_583<?> model;
   private final class_4597 vertexConsumers;

   public LivingEntityRenderEvent(
      class_1309 entity, class_10042 renderState, class_4587 matrices, class_583<?> model, class_4597 vertexConsumers
   ) {
      this.entity = entity;
      this.renderState = renderState;
      this.matrices = matrices;
      this.model = model;
      this.vertexConsumers = vertexConsumers;
   }

   public class_1309 entity() {
      return this.entity;
   }

   public class_10042 renderState() {
      return this.renderState;
   }

   public class_4587 matrices() {
      return this.matrices;
   }

   public class_583<?> model() {
      return this.model;
   }

   public class_4597 vertexConsumers() {
      return this.vertexConsumers;
   }

   public class_1309 a() {
      return this.entity;
   }

   public class_10042 b() {
      return this.renderState;
   }

   public class_4587 c() {
      return this.matrices;
   }

   public class_583<?> d() {
      return this.model;
   }

   public class_4597 e() {
      return this.vertexConsumers;
   }
}

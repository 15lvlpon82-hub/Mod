package pulse;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3966;
import pulse.client.MinecraftContext;

@HudServiceInfo
public class TargetTracker extends HudService implements MinecraftContext {
   private static final long TARGET_MEMORY_MS = 1000L;

   private class_1309 currentTarget;
   private final Map<class_1309, ElapsedTimer> recentlySeenTargets = new HashMap<>();
   private final ElapsedTimer clearTimer = new ElapsedTimer();
   private boolean waitingToClearTarget;

   @EventHandler
   public void onClientTick(ClientTickEvent event) {
      if (c.field_1724 == null || c.field_1687 == null) {
         return;
      }

      class_239 hitResult = c.field_1765;
      if (hitResult != null && hitResult.method_17783() == class_240.field_1331) {
         class_1297 entity = ((class_3966)hitResult).method_17782();
         if (entity instanceof class_1309 livingEntity && entity != c.field_1724 && !livingEntity.method_5767() && !EntityUtils.a(livingEntity)) {
            this.currentTarget = livingEntity;
            this.recentlySeenTargets.put(livingEntity, new ElapsedTimer());
            this.clearTimer.reset();
            this.waitingToClearTarget = true;
         }
      } else if (this.waitingToClearTarget && this.clearTimer.hasElapsed(TARGET_MEMORY_MS)) {
         this.currentTarget = null;
         this.waitingToClearTarget = false;
      }

      this.recentlySeenTargets.entrySet().removeIf(entry -> {
         class_1309 entity = entry.getKey();
         if (!entry.getValue().hasElapsed(TARGET_MEMORY_MS)) {
            return false;
         }

         if (entity instanceof class_1657 && entity.method_5767() && this.currentTarget == entity) {
            this.currentTarget = null;
            this.waitingToClearTarget = false;
         }

         return true;
      });
   }

   public boolean hasTarget() {
      return this.currentTarget != null;
   }

   public List<class_1309> recentTargets() {
      return new ArrayList<>(this.recentlySeenTargets.keySet());
   }

   public void clearTarget() {
      this.currentTarget = null;
      this.waitingToClearTarget = false;
      this.clearTimer.reset();
   }

   public void clearAll() {
      this.clearTarget();
      this.recentlySeenTargets.clear();
   }

   public class_1309 currentTarget() {
      return this.currentTarget;
   }

   public void a(ClientTickEvent event) {
      this.onClientTick(event);
   }

   public boolean d() {
      return this.hasTarget();
   }

   public List<class_1309> e() {
      return this.recentTargets();
   }

   public void f() {
      this.clearTarget();
   }

   public void g() {
      this.clearAll();
   }

   public class_1309 h() {
      return this.currentTarget();
   }
}
